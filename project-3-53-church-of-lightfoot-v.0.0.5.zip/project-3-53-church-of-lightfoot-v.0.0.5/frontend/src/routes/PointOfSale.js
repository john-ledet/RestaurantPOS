import React, { useEffect, useState } from "react";
import { Tab, Tabs } from "../components/POS/Tabs";
import { Item } from "../components/POS/Item";
import { executeGet, executePost } from "../util/Requests";

export const PointOfSale = () => {
  const tabs = ["MEAL", "SIDE", "ENTREE", "APPETIZER", "DRINK"];

  // Helper function to generate an empty order structure
  const generate_empty_order = () => {
    const empty_order = {};
    tabs.forEach((tab) => {
      empty_order[tab] = [];
    });
    return empty_order;
  };

  const [menu_items, set_menu_items] = useState([]);
  const [order, set_order] = useState(generate_empty_order());
  const [total, setTotal] = useState(0);
  const [current_tab, set_current_tab] = useState("MEAL");
  const [employee_id, set_employee_id] = useState(0);

  // Fetch menu items from the API
  const fetchMenuItems = async () => {
    try {
      const data = await executeGet("items", {}, "GET");
      set_menu_items(data); // Set fetched data directly
    } catch (error) {
      console.error("Error fetching menu items:", error);
    }
  };

  // Determine the next tab based on the updated order
  const check_for_next_tab = (updatedOrder) => {
    if (current_tab === "MEAL") {
      if (updatedOrder["MEAL"] && updatedOrder["MEAL"].length === 1) {
        return tabs[tabs.indexOf("MEAL") + 1];
      }
    } else if (current_tab === "SIDE") {
      const selectedMeal = updatedOrder["MEAL"][0];
      const nextTab = tabs[tabs.indexOf("SIDE") + 1];

      if (selectedMeal) {
        if (selectedMeal.name === "Bowl" && updatedOrder["SIDE"] && updatedOrder["SIDE"].length === 1) {
          return nextTab;
        } else if (selectedMeal.name === "Plate" && updatedOrder["SIDE"] && updatedOrder["SIDE"].length === 2) {
          return nextTab;
        } else if (selectedMeal.name === "Bigger Plate" && updatedOrder["SIDE"] && updatedOrder["SIDE"].length === 2) {
          return nextTab;
        }
      }

      return "SIDE";
    } else if (current_tab === "ENTREE") {
      const selectedEntree = updatedOrder["ENTREE"][0];
      const nextTab = tabs[tabs.indexOf("ENTREE") + 1];

      if (selectedEntree) {
        if (selectedEntree.name === "Bowl" && updatedOrder["ENTREE"] && updatedOrder["ENTREE"].length === 1) {
          return nextTab;
        } else if (selectedEntree.name === "Plate" && updatedOrder["ENTREE"] && updatedOrder["ENTREE"].length === 2) {
          return nextTab;
        } else if (selectedEntree.name === "Bigger Plate" && updatedOrder["ENTREE"] && updatedOrder["ENTREE"].length === 2) {
          return nextTab;
        }
      }

      return "ENTREE";
    }
    return "MEAL"; // Default or initial tab
  };

  // Add item to order and update the current tab accordingly
  const add_item_to_order = (item) => {
    set_order((prevOrder) => {
      const updatedOrder = {
        ...prevOrder,
        [item.item_type]: prevOrder[item.item_type].map((existingItem) => {
          if (existingItem.id === item.id) {
            return { ...existingItem, count: (existingItem.count || 1) + 1 }; // Increment count
          }
          return existingItem;
        }),
      };

      // If the item is new, add it to the order
      if (!updatedOrder[item.item_type].some((existingItem) => existingItem.id === item.id)) {
        updatedOrder[item.item_type].push({ ...item, count: 1 });
      }

      // Update current tab based on the newly updated order
      set_current_tab(check_for_next_tab(updatedOrder));
      setTotal(total + parseFloat(item.price));

      return updatedOrder;
    });
  };

  // Function to remove an item from the order
  const remove_item_from_order = (itemToRemove) => {
    set_order((prevOrder) => {
      const updatedOrder = {
        ...prevOrder,
        [itemToRemove.item_type]: prevOrder[itemToRemove.item_type]
          .map((item) => {
            if (item.id === itemToRemove.id) {
              return { ...item, count: (item.count || 1) - 1 }; // Decrement count
            }
            return item;
          })
          .filter((item) => item.count > 0), // Remove items with count 0
      };

      // Update total after removing the item
      setTotal(total - parseFloat(itemToRemove.price));

      // Update current tab if necessary
      return updatedOrder;
    });
  };

  const handleEmployeeIdChange = (e) => {
    set_employee_id(e.target.value);
  };

  const checkout = async () => {
    try {
      await executePost("items", {
        order,
        total,
        employee_id,
      });

      alert("ORDER SENT");
      set_order(generate_empty_order());
      setTotal(0);
      set_current_tab("MEAL");
      set_employee_id(0);
    } catch (error) {
      console.log(error);
    }
  };

  function formatItem(itemName, price, width = 40) {
    const formattedLine = itemName.padEnd(width - price.length, ".") + price;
    return formattedLine;
  }

  // Fetch menu items on initial render
  useEffect(() => {
    fetchMenuItems();
    return () => set_menu_items([]); // Cleanup function
  }, []);

  return (
    <div className="flex h-screen bg-gray-100">
      <div className="w-1/4 bg-white shadow-lg p-4">
        <div className="h-[calc(100vh-200px)] overflow-y-auto">
          {order &&
            Object.entries(order).map(
              ([tab, items]) =>
                items.length > 0 && (
                  <div key={tab} className="mb-4">
                    {items.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center py-2 border-b">
                        <div className="flex items-center">
                          <span className="mr-2">{item.count || 1}</span>
                          <span>{item.name}</span>
                        </div>
                        <span className="text-red-500">${item.price}</span>
                        <button onClick={() => remove_item_from_order(item)} className="text-red-500 ml-4">
                          Remove
                        </button>
                      </div>
                    ))}
                  </div>
                )
            )}
        </div>

        <div className="absolute bottom-0 left-0 w-1/4 bg-white p-4 border-t">
          <div className="flex justify-between mb-4">
            <span>Total:</span>
            <span className="text-red-500 font-bold">${total}</span>
          </div>
          <div className="flex flex-col gap-2">
            <input
              type="number"
              className="w-full border rounded p-2"
              placeholder="Employee ID"
              value={employee_id}
              onChange={handleEmployeeIdChange}
            />
            <button className="w-full bg-red-500 text-white py-2 rounded hover:bg-red-600" onClick={checkout}>
              Checkout
            </button>
          </div>
        </div>
      </div>

      {/* Right Side - Menu Items */}
      <div className="flex-1 p-4 w-full">
        <Tabs active={current_tab}>
          {tabs.map((tab) => (
            <Tab label={tab} key={tab}>
              <div className="grid grid-cols-3 gap-6 p-4">
                {menu_items
                  .filter((item) => item.item_type === tab)
                  .map((item) => (
                    <div
                      key={item.id}
                      onClick={() => add_item_to_order(item)}
                      className="bg-white p-4 rounded-lg shadow cursor-pointer hover:shadow-lg transition-shadow w-full"
                    >
                      <div className="flex justify-between items-center text-lg">
                        <span className="font-medium">{item.name}</span>
                        <span className="text-red-500">${item.price}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </Tab>
          ))}
        </Tabs>
      </div>
    </div>
  );
};
