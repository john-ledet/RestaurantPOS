import React, { useEffect, useState, useCallback } from 'react';
import { executeGet, executePost, executePut} from '../../util/Requests.js';
import {KioskTabs, KioskTab} from '../../components/Kiosk/KioskTabs.js';
import {KioskItemCard, KioskMealCard} from '../../components/Kiosk/KioskItemCard.js';
import { KioskModal, AddItemMenu, LaCarteMenu} from '../../components/Kiosk/KioskModal.js';
import {Logo} from '../../components/Kiosk/Logo.js';
import { KioskCheckout } from '../../components/Kiosk/KioskCheckout.js';
import AddItemPopup from "../../components/Kiosk/AddItemPopup.js";
import LanguageSelector from "../../components/LanguageSelector";

export const KioskOrder = () => {
  //STYLE SECTION
  const backgroundStyle = {
    height: "100vh",
    width: "100vw", 
    boxSizing: "border-box",
    fontFamily: "sans-serif", //Font controller
  };

  const orderComponents = ["MEAL", "SIDE", "ENTREE", "APPETIZER", "DRINK", "LACARTE", "CARTEITEMS"];
  const kioskTabs = ["Build Your Meal", "Appetizers", "Drinks", "La Carte"];
  const [menu_items, set_menu_items] = useState([]);
  const [current_tab, set_current_tab] = useState("Build Your Meal");
  const [total, setTotal] = useState(0.0);
  const [modalStatus, set_modal_status] = useState(false);
  const [addMultipleItemStatus, setAddMultipleItemStaus] = useState(false);
  const [checkoutStatus, setCheckout] = useState(false);
  const [carteMenuStatus, setCarteMenuStatus] = useState(false);
  const [itemToAdd, setItemToAdd] = useState("");
  const [numComponetsPerMeal, setNumComponets] = useState(0);
  const [rating, setRating] = useState(0);
  const [numItemsInOrder, setNumItemsInOrder] = useState(0);
  const [addItemAnimate, setAddItemAnimate] = useState(false);
  const [addItemStatus, setAddItemStatus] = useState(false);
  const [dynamicItems, setDynamicItems] = useState([]);
  const [triggeredFromAddItem, setTriggeredFromAddItem] = useState(false);
    const [noItemsMessage, setNoItemsMessage] = useState(false);
    const [nextOrderNum, setNextOrderNum] = useState(0); 

    const [loading, setLoading] = useState(false); // For spinner
    const [showCheckmark, setShowCheckmark] = useState(false); // For checkmark
    const [growModal, setGrowModal] = useState(false); // For modal growth
    const [showText, setShowText] = useState(false); // For final text

  //FUNCTIONS

  //returns an empty order for each order Component. Meal, Side, etc
  const generate_empty_order = () => {
    const empty_order = {};
    orderComponents.forEach((item_type) => {
      empty_order[item_type] = [];
    });
    return empty_order;
  };

  const [order, set_order] = useState(generate_empty_order());

  const calculateTotal = useCallback(() => {
    let total = 0.0;
    Object.keys(order).forEach((key) => {
      if(key !== "CARTEITEMS"){
        const itemArray = order[key];
        itemArray.forEach((item) => {
        //console.log("This is an Item: ", item)
        total += parseFloat(item.price);
      });
      }
    });
    setTotal(parseFloat(total.toFixed(2)));
    //console.log("CalculateTotal result = ", total);
  }, [order]);

  const calculateNumOfItems = () => {
    let totalItems = 0; 
    Object.keys(order).forEach(key => {
      if(key !== "CARTEITEMS" && key !== "SIDE" && key !== "ENTREE"){
        const itemArray = order[key];
        itemArray.forEach(item => {
          totalItems++;
        });
      }
    });

    if(totalItems !== 0 && numItemsInOrder < totalItems){
      setAddItemAnimate(true);
      setTimeout(() => {
        setNumItemsInOrder(totalItems);
      }, 1000);

      setTimeout(() => {
        setAddItemAnimate(false);
      }, 2000); 
    }else{
      setNumItemsInOrder(totalItems);
    }
  };

  const addImages = useCallback((menu_items) => {
    return menu_items.map((item) => {
       

      if(item.item_type === "SEASONAL"){
        return {
          ...item,
          itemImage: `/ImageFolder/special_icon.png`,
        };
      }else{
        let imageName = item.name.toLowerCase().replace(/\s+/g, "_") + ".png";
        return {
          ...item,
          itemImage: `/ImageFolder/${imageName}`,
        };
      }
    });
  }, []);

  //Handles the order sent from Build Your Own Menu
  const handleMealOrder = (mealOrder) => {
    set_order((prevOrder) => ({
      ...prevOrder,
      MEAL: [...prevOrder["MEAL"], ...mealOrder["MEAL"]],
      SIDE: [...prevOrder["SIDE"], ...mealOrder["SIDE"]],
      ENTREE: [...prevOrder["ENTREE"], ...mealOrder["ENTREE"]],
    }));
  };

  const addItemToOrder = (item) => {
    set_order((prevOrder) => {
      const updatedOrder = {
          ...prevOrder,
          [item.item_type]: [...prevOrder[item.item_type], item]
      };
          
      return updatedOrder;
    });
  };

  const addCartetoOrder = (size, item) => {
    set_order((prevOrder) => ({
      ...prevOrder,
      LACARTE: [...prevOrder["LACARTE"], size],
      CARTEITEMS: [...prevOrder["CARTEITEMS"], item],
    }));
  };

  const fetchMenuItems = useCallback(async () => {
    try {
      const data = await executeGet("kiosk", {}, "GET");
      const dataWithImages = addImages(data);
      set_menu_items(dataWithImages); // Set fetched data directly
    } catch (error) {
      console.error("Error fetching menu items:", error);
    }
  }, [addImages]);

  // Fetch menu items on initial render
  useEffect(() => {
    fetchMenuItems();
    //console.log("These are the menu items: ", menu_items);
    return () => set_menu_items([]); // Cleanup function
  }, [fetchMenuItems]);

  const fetchOrderNumber = async() => {
    try{
      const res = await executeGet("kiosk/nextorder", {}, "GET");
      setNextOrderNum(res.order_id);
    }catch (error) {
      console.error("Error fetching menu items:", error);
    }
  }

  const openModal = (item) => {
    set_modal_status(true);

    if (item.name === "Bowl") {
      setNumComponets(2);
    } else if (item.name === "Plate") {
      setNumComponets(3);
    } else {
      setNumComponets(4);
    }
  };

  const closeModal = () => {
    set_modal_status(false); // Close the modal
    if (triggeredFromAddItem) {
      setTriggeredFromAddItem(false); // Reset the flag
      setCheckout(true); // Open checkout
    }
  };

  const openAddItemMenu = (item) => {
    setAddMultipleItemStaus(true);
    setItemToAdd(item);
  };

  const closeAddItemMenu = () => {
    setAddMultipleItemStaus(false);
    setItemToAdd("");
  };

  const openCarteMenu = (item) => {
    setCarteMenuStatus(true);
    setItemToAdd(item);
  };

  const closeCarteMenu = () => {
    setCarteMenuStatus(false);
    setItemToAdd("");
  };

  const deleteFromOrder = useCallback(
    (item, index) => {
      //if we are deleting a side we need to consider the index of sides and entrees
      if (item.item_type === "MEAL") {
        let startForSide = index * 2;
        let startForEntree = 0;

      for (let i = 0; i < index; i++) {
        if (order["MEAL"][i].name === "Bowl") {
          startForEntree += 1;
        } else if (order["MEAL"][i].name === "Plate") {
          startForEntree += 2;
        } else {
          startForEntree += 3;
        }
      }

      set_order((prevOrder) => {
        let numOfEntrees = 1;
        if (item.name === "Plate") {
          numOfEntrees = 2;
        } else if (item.name === "Bigger Plate") {
          numOfEntrees = 3;
        }

        const updatedOrder = {
          ...prevOrder,
          MEAL: [
            ...prevOrder.MEAL.slice(0, index),
            ...prevOrder.MEAL.slice(index + 1),
          ],
          SIDE: [
            ...prevOrder.SIDE.slice(0, startForSide),
            ...prevOrder.SIDE.slice(startForSide + 2),
          ],
          ENTREE: [
            ...prevOrder.ENTREE.slice(0, startForEntree),
            ...prevOrder.ENTREE.slice(startForEntree + numOfEntrees),
          ],
        };
        return updatedOrder;
      });
    }else if(item.item_type === "LACARTE"){
      set_order((prevOrder) => {
        const updatedOrder = {
          ...prevOrder,
          LACARTE: [
            ...prevOrder["LACARTE"].slice(0, index),
            ...prevOrder["LACARTE"].slice(index + 1),
          ],
          CARTEITEMS: [
            ...prevOrder["CARTEITEMS"].slice(0, index),
            ...prevOrder["CARTEITEMS"].slice(index + 1),
          ],
        };
        return updatedOrder;
      });
    }else {
      set_order((prevOrder) => {
        const updatedOrder = {
          ...prevOrder,
          [item.item_type]: [
            ...prevOrder[item.item_type].slice(0, index),
            ...prevOrder[item.item_type].slice(index + 1),
          ],
        };
        return updatedOrder;
      });
    }
  }, [order]);

  const addToDatabase = async (groupedOrder) => {
    try {
      await executePost("kiosk/database", {
        order,
        groupedOrder,
        total,
        rating,
      });

    } catch (error) {
      console.log(error);
    }
  };

  const updateIventory = async () => {
    try {
      await executePut("kiosk/updateInventory", {
        order,
      });

    } catch (error) {
      console.log(error);
    }
  }

  const groupMealItems = () => {
    let groupNumber = 1;
    const groupedOrder = [];

    order["MEAL"].forEach((mealItem, mealIndex) => {
      const mealGroup = {
        type: "MEAL",
        groupNum: groupNumber,
        meal: mealItem,
        entrees: [],
        sides: [],
      };

      let entreeCount = 1;
      if (mealItem.name === "Plate") entreeCount = 2;
      else if (mealItem.name === "Bigger Plate") entreeCount = 3;

      let entreeStartIndex = 0;
      for (let i = 0; i < mealIndex; i++) {
        if (order["MEAL"][i].name === "Bowl") {
          entreeStartIndex += 1;
        } else if (order["MEAL"][i].name === "Plate") {
          entreeStartIndex += 2;
        } else {
          entreeStartIndex += 3;
        }
      }
      //console.log("Entree Start Index is at ", entreeStartIndex);
      mealGroup.entrees = order["ENTREE"].slice(
        entreeStartIndex,
        entreeStartIndex + entreeCount
      );
      mealGroup.sides = order["SIDE"].slice(mealIndex * 2, mealIndex * 2 + 2);

      groupedOrder.push(mealGroup);
      groupNumber += 1;
    });

    order["APPETIZER"].forEach((menuItem) => {
      const orderItem = {
        type: "APPETIZER",
        groupNum: groupNumber,
        item: menuItem,
      };
      groupedOrder.push(orderItem);
      groupNumber += 1;
    });

    order["DRINK"].forEach((menuItem) => {
      const orderItem = {
        type: "DRINK",
        groupNum: groupNumber,
        item: menuItem,
      };
      groupedOrder.push(orderItem);
      groupNumber += 1;
    });

    order["LACARTE"].forEach((carteSize, carteIndex) => {
      const orderLaCarte = {
        type: "LACARTE",
        groupNum: groupNumber,
        size: carteSize,
        item: order["CARTEITEMS"][carteIndex],
      };
      groupedOrder.push(orderLaCarte);
      groupNumber += 1;
    });

    groupedOrder.sort((a, b) => a.groupNum - b.groupNum);
    return groupedOrder;
  };

  const processCheckout = async () => {
    const groupedOrder = groupMealItems();
    //console.log(groupedOrder);
    closeCheckout(); 
    await addToDatabase(groupedOrder, rating);
    await updateIventory(); 

    fetchOrderNumber();
    
    setLoading(true); // Start loading
    setShowCheckmark(false);
    setGrowModal(false);
    setShowText(false);

    // Simulate loading process
    setTimeout(() => {
      setLoading(false); // End spinner
      setShowCheckmark(true); // Show checkmark
      setTimeout(() => {
        setGrowModal(true); // Grow modal
        setTimeout(() => {
          setShowText(true); // Show final text
          setTimeout(() => {
            window.location.href = "/kioskStart"; // Navigate to the next page
          }, 4000);
        }, 800); // Growth animation duration
      }, 1000); // Checkmark display duration
    }, 2000); // Loading duration
    
    
  };

  const cancelOrder = () => {
    window.location.href = "/kioskStart";
  };

  const openCheckout = () => {
    if (parseFloat(total) === 0) {
      setNoItemsMessage(true);
    } else {
      // Filter dynamic items for the popup
      const getRandomItemByCategory = (items, category) => {
        const filteredItems = items.filter((item) => item.item_type === category);
        if (filteredItems.length === 0) return null; // Return null if no items in the category
        const randomIndex = Math.floor(Math.random() * filteredItems.length);
        return filteredItems[randomIndex];
      };
  
      // Get random items for each category
      const randomAppetizer = getRandomItemByCategory(menu_items, "APPETIZER");
      const randomDrink = getRandomItemByCategory(menu_items, "DRINK");
      const randomMeal = getRandomItemByCategory(menu_items, "MEAL");

      const selectedItems = [randomAppetizer, randomDrink, randomMeal].filter(Boolean); // Remove undefined/null items

      setDynamicItems(selectedItems); // Set the filtered items
      setAddItemStatus(true); // Trigger Add Item Popup
    }
  };

  const closeCheckout = useCallback(() => {
    setCheckout(false);
  }, []);

  const handleAddItem = (item) => {
    if (item.item_type === "MEAL") {
      openModal(item);
      setAddItemStatus(false); // Close Add Item Popup immediately
      setTriggeredFromAddItem(true); // Track source
    } else {
      // Directly add appetizers and drinks to the order
      set_order((prevOrder) => ({
        ...prevOrder,
        [item.item_type]: [...prevOrder[item.item_type], item],
      }));
      setAddItemStatus(false);
      setCheckout(true); // Proceed to checkout
    }
  };

  const skipAddItem = () => {
    setAddItemStatus(false);
    setCheckout(true); // Proceed to checkout without adding
  };
  
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === "Escape") {
        closeModal();
      }
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [closeModal]);

  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === "Escape") {
        closeCheckout();
      }
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [closeCheckout]);

  useEffect(() => {
    //If the cart is empty close out of checkout
    if (parseFloat(total) === 0) {
      closeCheckout();
    }
  }, [closeCheckout, deleteFromOrder, total]);

  useEffect(() => {
    console.log("Current order is", order);
    calculateTotal();
    calculateNumOfItems();
  }, [calculateTotal, order]);

  useEffect(() => {
    //console.log(total);
  }, [total]);

  useEffect(() => {
    //console.log("Number of componets is ", numComponetsPerMeal);
  }, [numComponetsPerMeal]);

    return (
        <div className = "flex items-center justify-center h-screen bg-white">
            <div style = {backgroundStyle} className = "flex flex-col bg-amber-50">

                {/*HEADER SECTION */}
                {<nav className="bg-red-500 w-full max-h-[10%] shadow-sm shadow-black">
                    <div className="flex items-center justify-between w-full h-full">
                        {/* Logo Section */}
                        <div className="flex items-center h-full w-[40%]">
                            <Logo width = "w-[15%]" height = "h-auto"/>
                            <LanguageSelector />
                        </div>
        
                        {/* Checkout Button */}
                        <div className = "flex justify-end h-full w-[40%]">
                            <div className="relative h-full w-[20%] flex justify-end">
                              <img src = "/ImageFolder/Shopping_Cart.png" className="object-contain h-auto w-[80%]"/>
                              <div className={`  absolute right-7 top-6 ${addItemAnimate ? 'animate-bounceCustom' : ''}  bg-black w-[25px] h-[20px] 
                              rounded-sm text-yellow-300 font-semibold
                              flex items-center justify-center`}>{numItemsInOrder}</div>
                            </div>
                            <div className="text-white font-semibold text-xl h-full w-[30%] flex items-end">
                              <p>Total: $</p>
                              <p>{parseFloat(total).toFixed(2)}</p>
                            </div>
                        </div>
                    </div>
                </nav>}

                {addItemStatus && (
                  <AddItemPopup
                    items={dynamicItems} // Pass the dynamically filtered items
                    onAddItem={handleAddItem}
                    onSkip={skipAddItem}
                  />
                )}

                {/*Kiosk TABS */}
                <KioskTabs active = {current_tab}>
                    {kioskTabs.map(tab => (
                        <KioskTab label={tab} key={tab}>
                            {menu_items.map(item => {
                            
                                const normalizedTab = tab === "Build Your Meal" 
                                ? "MEAL" 
                                : tab === "Appetizers"
                                ? "APPETIZER"
                                : tab === "Drinks"
                                ? "DRINK"
                                : tab === "La Carte"
                                ? "LACARTE"
                                : tab; 
                                const handleClick = item.item_type === "MEAL"
                                    ? (e) => openModal(item)
                                    : item.item_type === "APPETIZER" || item.item_type === "DRINK"
                                    ? (e) => openAddItemMenu(item)
                                    : (e) => openCarteMenu(item); 
                                
                                if(item.item_type === normalizedTab && normalizedTab === "MEAL"){
                                  return (
                                    <KioskMealCard key={item.id} onClick={handleClick} item={item} picture={item.itemImage}/>
                                  );
                                }else if(item.item_type === normalizedTab && normalizedTab === "APPETIZER"){
                                  return (
                                    <KioskItemCard key={item.id} onClick={handleClick} item={item} picture={item.itemImage}
                                    cardSize={'2xl:h-[550px] 2xl:w-[450px] h-[350px] w-[300px]'} infoStyle={'w-[10%] h-[8%] z-10 absolute top-0.5 left-1 p-2 text-sm font-semibold'}
                                    nameSize={'2xl:text-2xl text-lg h-[10%]'} pictureSize={'w-[full] 2xl:h-[250px] h-[150px]'}
                                    priceSize={'h-[20%] 2xl:text-2xl text-lg'} spicySize={'w-[15%]'} wokSize={'w-[17%]'}
                                    />
                                  );
                                }else if(item.item_type === normalizedTab && normalizedTab === "DRINK"){
                                  return (
                                    <KioskItemCard key={item.id} onClick={handleClick} item={item} picture={item.itemImage}
                                    cardSize={'2xl:h-[550px] 2xl:w-[450px] h-[350px] w-[300px]'} infoStyle={'w-[10%] h-[8%] absolute top-0.5 left-1 p-2 text-sm font-semibold'}
                                    nameSize={'2xl:text-2xl text-lg h-[10%]'} pictureSize={'w-[full] 2xl:h-[250px] h-[150px]'}
                                    priceSize={'h-[20%] 2xl:text-2xl text-lg'} spicySize={'w-[15%]'} wokSize={'w-[17%]'}
                                    />
                                  );
                                }else if ((item.item_type === "SIDE" || item.item_type === "ENTREE" || item.item_type === "SEASONAL") && normalizedTab === "LACARTE"){
                                  return (
                                    <KioskItemCard key={item.id} onClick={handleClick} item={item} picture={item.itemImage}
                                    cardSize={'2xl:h-[550px] 2xl:w-[450px] h-[250px] w-[200px]'} infoStyle={'w-[10%] h-[8%] absolute top-0.5 left-1 p-2 text-sm font-semibold'}
                                    nameSize={'2xl:text-2xl text-lg h-[15%] w-[65%]'} pictureSize={'w-[full] 2xl:h-[250px] h-[150px]'}
                                    priceSize={'h-[20%] 2xl:text-2xl text-lg opacity-0'} messageStyle={'h-[10%] bottom-10 font-semibold text-sm'} spicySize={'w-[15%]'} wokSize={'w-[17%]'}
                                    />
                                  );
                                }   
                            })}
                        </KioskTab>
                    ))}
                </KioskTabs>
                
                {/*BUILD YOUR MEAL MENU SECTION*/}
                <div className= {`${modalStatus === false ? 'hidden' : ''} fixed inset-0 bg-black/50 flex items-center justify-center z-50`} aria-modal="true">
                    <div className="bg-amber-50 w-[70vw] h-[98vh] relative rounded-lg shadow-lg" onClick={(e) => e.stopPropagation()}>
                        <KioskModal numOfComponents = {numComponetsPerMeal} menuItems={menu_items} onClose = {closeModal} orderHandler={handleMealOrder}/>
                    </div>
                </div>

                {/*Add Items menu SECTION*/}
                <div className= {`${addMultipleItemStatus === false ? 'hidden' : ''} fixed inset-0 bg-black/50 flex items-center justify-center z-50`} aria-modal="true">
                    <div className="bg-amber-50 w-[30vw] h-[75vh] relative rounded-lg shadow-lg" onClick={(e) => e.stopPropagation()}>
                        <AddItemMenu item = {itemToAdd} addItemHandler = {addItemToOrder} onClose={closeAddItemMenu}/>
                    </div>
                </div>
                
                {/*La Carte Menu SECTION*/}
                <div className= {`${carteMenuStatus === false ? 'hidden' : ''} fixed inset-0 bg-black/50 flex items-center justify-center z-50`} aria-modal="true">
                    <div className="bg-amber-50 w-[40vw] h-[95vh] relative rounded-lg shadow-lg" onClick={(e) => e.stopPropagation()}>
                        <LaCarteMenu item = {itemToAdd} menuItems={menu_items} addItemHandler={addCartetoOrder} onClose = {closeCarteMenu}/>
                    </div>
                </div>

                {/*CHECKOUT SECTION*/}
                <div className= {`${ checkoutStatus === false ? 'hidden' : ''} fixed inset-0 bg-black/50 flex items-center justify-center z-50`} aria-modal="true">
                    <div className="bg-amber-50 w-[37vw] h-[95vh]  relative rounded-lg shadow-lg" onClick={(e) => e.stopPropagation()}>
                        <KioskCheckout onClose = {closeCheckout} onCheckout = {processCheckout} deleteItem={deleteFromOrder} currentOrder={order} currentTotal={total} setRating={setRating}/>
                    </div>
                </div>

                {/*No Item Message*/}
                <div className= {`${ noItemsMessage === false ? 'hidden' : ''} fixed inset-0 bg-black/50 flex items-center justify-center z-50`} aria-modal="true">
                    <div className="bg-amber-50 w-[20vw] h-[20vh]  relative rounded-lg shadow-lg" onClick={(e) => e.stopPropagation()}>
                        <div className='w-full h-full flex items-center justify-center'>
                          <button
                            className="absolute left-2 top-1 rounded-md font-semibold text-3xl "
                            onClick={() => setNoItemsMessage(false)}
                          >
                            X
                          </button>
                          <p className='font-semibold text-lg'>No Items in the Cart!</p>
                        </div>
                    </div>
                </div>

                {(loading || showCheckmark || growModal || showText) && (
                  <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                    <div
                    className={`bg-white flex items-center justify-center rounded-lg p-3 transition-all transform ${
                    growModal ? "w-[45vw] h-[50vh] animate-grow" : " w-[10vw] h-[20vh]"
                    }`}
                    >
                      {loading && (
                      <img
                      src="/ImageFolder/loading_icon.png"
                      alt="Loading..."
                      className="object.contain animate-spin"
                      />
                      )}

                      {showCheckmark && !growModal && (
                      <img
                      src="/ImageFolder/completed_icon.png"
                      alt="Checkmark"
                      className="w-16 h-16"
                      />
                      )}

                      {showText && (
                      <div className=' w-full h-full flex flex-col gap-5 items-center justify-center'>
                        <p className='text-5xl font-semibold'>Checkout Complete!</p>
                        <p className='text-3xl'>Your Order Number Is</p>
                        <p className='text-4xl font-semibold'><u>{nextOrderNum}</u></p>
                      </div>
                      )}
                    </div>
                  </div>
                )}

                {/*FOOTER SECTION*/}
                <div className = "bg-red-500 w-full h-[10%] shadow-sm shadow-black flex items-center justify-between">
                  <button className = "w-[20%] h-[85%] ml-1 bg-white hover:bg-black hover:text-yellow-300 font-semibold text-xl"
                  onClick={() => cancelOrder()}>
                    Cancel Order
                  </button>

                  <button className="w-[20%] h-[85%] mr-1 bg-white hover:bg-black hover:text-yellow-300 font-semibold text-xl" onClick={ () => openCheckout()}>
                    Place Order
                  </button>
                </div>
              </div>
            </div>
  );
};
