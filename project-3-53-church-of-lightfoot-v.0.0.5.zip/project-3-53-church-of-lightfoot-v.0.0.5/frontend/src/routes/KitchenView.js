import React from "react";
import KioskOrderList from "../components/Kiosk/KioskOrderList";

export const KitchenView = () =>{
return (
    <KioskOrderList/>
);
};