import React from "react";
import CompletedOrderList from "../components/Kitchen/CompletedOrderList";

export const CompletedView = () =>{
return (
    <CompletedOrderList/>
);
};