import React, { useState, useEffect, useCallback } from "react";
import DatePicker from "react-datepicker";
import { executeGet, executePost } from "../../util/Requests";
import { TimeDictionary } from "../../util/TimestampDictionary";

import "react-datepicker/dist/react-datepicker.css";

const OrderHistory = () => {
  const dateFormatter = (initialDate, isEndDate) => {
    const date = initialDate;

    if (isEndDate) {
      date.setHours(23);
      date.setMinutes(59);
      date.setSeconds(59);
      date.setMilliseconds(0);
    } else {
      date.setHours(6);
      date.setMinutes(0);
      date.setSeconds(0);
      date.setMilliseconds(0);
    }

    return date;
  };
  const getToday = (isEndDate) => {
    const today = new Date();
    return dateFormatter(today, isEndDate);
  };

  const [startDate, setStartDate] = useState(getToday(false));
  const [endDate, setEndDate] = useState(getToday(true));
  const [orders, setOrders] = useState([]);
  const [todaysOrders, setTodaysOrders] = useState([]);
  const [zReportWindow, setZReportWindow] = useState(false);

  const fetchData = useCallback(async () => {
    if (startDate && endDate) {
      const adjustedStartDate = new Date(startDate);
      const adjustedEndDate = new Date(endDate);
      const adjustedStartDate2 = new Date(startDate);
      const adjustedEndDate2 = new Date(endDate);
      adjustedStartDate.setHours(adjustedStartDate.getHours() - 6);
      adjustedEndDate.setHours(adjustedEndDate.getHours() - 6);
      adjustedStartDate2.setHours(adjustedStartDate.getHours() - 6);
      adjustedEndDate2.setHours(adjustedEndDate.getHours() - 6);
      
      try {
        const data = await executeGet(
          `orders?startDate=${dateFormatter(
            adjustedStartDate,
            false
          ).toISOString()}&endDate=${dateFormatter(
            adjustedEndDate,
            true
          ).toISOString()}`,
          {},
          "GET"
        );
        setOrders(data);

        const data2 = await executeGet(
          `orders?startDate=${dateFormatter(
            adjustedStartDate2,
            false
          ).toISOString()}&endDate=${dateFormatter(
            adjustedEndDate2,
            true
          ).toISOString()}`,
          {},
          "GET"
        );
        setTodaysOrders(data2);

      } catch (error) {
        console.error("Error fetching data:", error);
        setOrders([]);
      }
    } else {
      setOrders([]);
    }
  }, [startDate, endDate]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const dataFromDate = useCallback(async (today) => {
    const start = dateFormatter(today, false);
    const end = dateFormatter(today, true);
    try {
      const data = await executeGet(
        `orders?startDate=${start}&endDate=${end}`,
        {},
        "GET"
      );
      return data.filter((item) => item.reportable === true);
    } catch (error) {
      console.error("Error fetching data:", error);
      return [];
    }
  }, []);

  const salesReport = (orderData) => {
    if (orderData.length === 0) {
      console.error("Dataset is empty! Select a start and end date.");
      return;
    }

    const headers = Object.keys(orderData[0]);
    let csv = `${headers.join(",")}\n`;
    orderData.forEach((obj) => {
      const row = headers.map((header) => `"${obj[header] || ""}"`).join(",");
      csv += `${row}\n`;
    });

    const blob = new Blob([csv], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "SalesReport.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const zReportWindowEnable = () => {
    setZReportWindow(true);
  };
  const zReportWindowDisable = () => {
    setZReportWindow(false);
  };

  const xReport = useCallback(async () => {
    try {
      // Fetch fresh data directly
      const data = await dataFromDate(new Date());
      if (!data || data.length === 0) {
        console.error("No data available for generating X Report.");
        return;
      }
  
      // Generate CSV content
      const hourMap = new Map();
      const headers = "Hour,Total";
      let csv = `${headers}\n`;
  
      const timeDictionary = TimeDictionary();
      data.forEach((obj) => {
        const hour = obj.timestamp.split("T")[1].split(":")[0];
        const value = parseFloat(obj.total);
        hourMap.set(hour, (hourMap.get(hour) ?? 0) + value);
      });
  
      hourMap.forEach((total, hour) => {
        csv += `${timeDictionary[hour]},${total.toFixed(2)}\n`;
      });
  
      // Trigger file download
      const blob = new Blob([csv], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "xReport.csv";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  
      console.log("X Report successfully downloaded.");
    } catch (error) {
      console.error("Error generating X Report:", error);
    }
  }, [dataFromDate]);
  

  const zReport = useCallback(async () => {
    var data;
    var menuItemIDs = [];
    const itemIDMap = new Map();

    try {
      data = await executeGet(`orders/zReport`, {}, "GET");
      let dataString = JSON.stringify(data);
      if (dataString === "[]") {
        console.error(
          "Empty data set encountered! Place some orders to populate data for the z-report!"
        );
        return;
      }
      let menuItems = await executeGet(
        `orders/menuItemIDs?orders=${dataString}`,
        {},
        "GET"
      );
      for (let i = 0; i < Object.keys(menuItems).length; i++) {
        menuItemIDs.push(menuItems[i].menu_item_id);
      }

      for (let i = 0; i < menuItemIDs.length; i++) {
        itemIDMap.set(menuItemIDs[i], (itemIDMap.get(menuItemIDs[i]) ?? 0) + 1);
      }

      // console.log(itemIDMap);
    } catch (error) {
      console.error("Error with JSON fetching! ", error);
    }

    setTodaysOrders(data);
    var total = 0;

    let csv = "~~Today's Total~~\n$";

    for (const obj of todaysOrders) {
      total += parseFloat(Object.values(obj)[1]);
    }
    csv +=
      total + "\n\n~~Ingredient Usage~~\nIngredient Name,Quantity Used,Units\n";

    let itemIngredientData = await executeGet(`inventory/orders`, {}, "GET");
    // console.log(itemIngredientData);

    // O(n^2) sorry :(
    var ingredientUsageMap = new Map();
    for (const [itemID, numTimesUsed] of itemIDMap) {
      for (const menuItem of itemIngredientData) {
        if (menuItem.menu_item_id === itemID) {
          ingredientUsageMap.set(
            menuItem.ingredient_id,
            menuItem.quantity_used * numTimesUsed
          );
        }
      }
    }

    for (const [ingredientID, quantityUsed] of ingredientUsageMap) {
      const ingredientData = await executeGet(
        `inventory/name?ingredient=${ingredientID}`,
        {},
        "GET"
      );
      csv +=
        ingredientData[0].name +
        "," +
        quantityUsed +
        "," +
        ingredientData[0].unit +
        "\n";
    }

    // console.log(csv);

    const blob = new Blob([csv], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "zReport.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    try {
      await executePost(`orders/reset`, {});
    } catch (error) {
      console.error("Error resetting the orders for the day: ", error);
    }
    zReportWindowEnable(true);
  }, [todaysOrders]);

  const buttonStyle =
    "bg-red-500 text-white font-semibold rounded-md hover:bg-red-600 active:bg-red-700 disabled:bg-gray-400 disabled:text-gray-600";

  const ZReportConfirmation = () => {
    return (
      <div className="fixed top-[50%] left-[50%] w-[40%] translate-x-[-50%] translate-y-[-50%] p-[20px] bg-red-50 rounded-md border border-gray-300">
        <div className="flex justify-between">
          <div>
            <h3 className="text-lg font-medium">
              Z-Report Generated. Cleared today's sales data.
            </h3>
          </div>
          <div className="flex justify-between mt-4">
            <button
              className="px-3 py-1 bg-red-500 text-white rounded-md"
              onClick={zReportWindowDisable}
            >
              OK
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="relative flex gap-[20px] justify-center">
      <div>
        <h3 className="text-lg font-medium">Start Date</h3>
        <DatePicker
          selected={startDate}
          onChange={(date) => setStartDate(dateFormatter(date, false))}
          isClearable
          placeholderText="Select start date"
          inline
        />
        <h3 className="text-lg font-medium">End Date</h3>
        <DatePicker
          selected={endDate}
          onChange={(date) => setEndDate(dateFormatter(date, true))}
          minDate={startDate}
          isClearable
          placeholderText="Select end date"
          inline
        />
      </div>
      <div className="h-[600px] overflow-y-auto">
        <table className="table-fixed">
          <thead className="text-md">
            <tr className="bg-gray-100">
              <th className="px-[20px] p-2 border-t border-b border-l text-center">
                Order ID
              </th>
              <th className="px-[20px] p-2 border-t border-b border-l text-center">
                Total ($)
              </th>
              <th className="px-[20px] p-2 border-t border-b border-l text-center">
                Timestamp
              </th>
              <th className="px-[20px] p-2 border-t border-b border-l border-r text-center">
                Employee ID
              </th>
            </tr>
          </thead>
          {orders.length > 0 ? (
            <tbody>
              {orders.map((order) => (
                <tr key={order.order_id}>
                  <td className="p-2 border-b border-l text-center">
                    {order.order_id}
                  </td>
                  <td className="p-2 border-b border-l text-center">
                    {order.total}
                  </td>
                  <td className="p-2 border-b border-l text-center">
                    {new Date(order.timestamp).toLocaleDateString()}
                  </td>
                  <td className="p-2 border-b border-l border-r text-center">
                    {order.employee_id}
                  </td>
                </tr>
              ))}
            </tbody>
          ) : (
            <tbody>
              <tr>
                <th colSpan="4" className="sticky">
                  {!startDate || !endDate
                    ? "Select start and end dates to show all orders in that date range."
                    : "No data available for the selected date range."}
                </th>
              </tr>
            </tbody>
          )}
        </table>
      </div>
      <div className="grid h-[20px]">
        <button
          disabled={orders.length === 0}
          className={"px-6 py-2 mb-[20px] " + buttonStyle}
          onClick={() => salesReport(orders)}
        >
          Generate Sales Report
        </button>
        <div className="grid gap-[20px] px-5 py-2 border-t border-gray-300">
          <button
            disabled={todaysOrders.length === 0}
            className={"px-6 py-2 " + buttonStyle}
            onClick={() => xReport()}
          >
            Generate X Report
          </button>
          <button
            disabled={todaysOrders.length === 0}
            className={"px-6 py-2 " + buttonStyle}
            onClick={() => zReport()}
          >
            Generate Z Report
          </button>
        </div>
      </div>
      <div className="z-10">{zReportWindow && <ZReportConfirmation />}</div>
    </div>
  );
};

export default OrderHistory;
