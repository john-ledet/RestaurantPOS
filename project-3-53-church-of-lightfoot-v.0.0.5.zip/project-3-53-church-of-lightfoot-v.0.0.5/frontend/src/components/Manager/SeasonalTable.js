import React from 'react';

export const SeasonalTable = ({ items, onRemove }) => {
    return (
        <section>
            <div className = "table-container">
                <table className = "w-full border-collapse">
                    <thead>
                        <tr>
                            <th className="border border-gray-300 p-2">Dish ID</th>
                            <th className="border border-gray-300 p-2">Dish Name</th>
                            <th className="border border-gray-300 p-2">Dish Price</th>
                            <th className="border border-gray-300 p-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items.map(item => ( 
                                <tr key={item.menu_item_id}>
                                    <td className="border border-gray-300 p-2">{item.menu_item_id}</td>
                                    <td className="border border-gray-300 p-2">{item.name}</td>
                                    <td className="border border-gray-300 p-2">${parseFloat(item.price).toFixed(2)}</td>
                                    <td className="border border-gray-300 p-2">
                                        <button className="bg-red-500 text-white px-2 py-1 rounded" onClick = {() => onRemove(item.menu_item_id)}>Remove</button>
                                    </td>
                                </tr>
                            ))}
                    </tbody>
                </table>
            </div>
        </section>
    );
};
