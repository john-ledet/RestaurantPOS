import React from "react";

function CompletedOrder({ completedTime, orderId, items }) {
  const formattedTime = new Date(completedTime).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true, 
  });

  const groupedItems = items.reduce((groups, item) => {
    if (!groups[item.itemgroup]) {
      groups[item.itemgroup] = [];
    }
    groups[item.itemgroup].push(item);
    return groups;
  }, {});

  return (
    <div className="box-border w-72 p-4 border rounded-lg text-black shadow-lg flex flex-col justify-start min-h-40 max-h-full h-auto bg-gray-200 border-gray-300">
      
      <div className="flex justify-between text-lg text-gray-600 mb-4">
        <span>
          Completed: <span className="whitespace-nowrap">{formattedTime}</span>
        </span>
        <span>Order #{orderId}</span>
      </div>

     
      <div className="text-left text-lg flex-grow">
        <ul>
          {Object.entries(groupedItems).map(([group, groupItems]) => (
            <li key={group} className="mb-2">
              {groupItems[0].name} (x{groupItems[0].quantity})
              <ul className="pl-4 list-disc list-inside">
                {groupItems.map((item, index) => (
                  <li key={index}>{item.name}</li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default CompletedOrder;
