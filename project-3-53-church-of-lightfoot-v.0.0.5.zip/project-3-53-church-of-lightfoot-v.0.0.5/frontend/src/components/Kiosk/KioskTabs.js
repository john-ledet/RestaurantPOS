import React, { useState, useEffect } from "react";

const KioskTabs = ({ active, children }) => {
  const iconStyle = "w-[full] 2xl:h-[100px] lg:h-[60px] object-cover";
  const [activeTab, setActiveTab] = useState(active);

  useEffect(() => {
    setActiveTab(active);
  }, [active]);

  const handleClick = (e, newActiveTab) => {
    e.preventDefault();
    setActiveTab(newActiveTab);
  };

  return (
    <div className="w-full h-[80%] flex font-sans">
      <div className="w-[15%] h-full flex flex-col items-center shadow-sm shadow-black ">
        {/*TABS*/}
        {children.map((child) => (
          <button
            key={child.props.label}
            className={`${
              activeTab === child.props.label ? "bg-red-500 text-white" : "bg-white text-black"
            } w-[80%] h-[20%] flex flex-col items-center justify-center
                        mt-5 rounded-md shadow-sm shadow-black
                        font-semibold 2xl:text-2xl`}
            onClick={(e) => handleClick(e, child.props.label)}
          >
            {child.props.label}
            <div className="w-full h-[75%] flex items-center justify-center">
              {(() => {
                if (child.props.label === "Build Your Meal") {
                  return (
                    <img
                      className={iconStyle}
                      src="/ImageFolder/build_your_own1.png"
                    />
                  );
                } else if (child.props.label === "Appetizers") {
                  return (
                    <img
                      className={iconStyle}
                      alt = "Appetizers"
                      src="/ImageFolder/appetizer.png"
                    />
                  );
                } else if (child.props.label === "Drinks"){
                  return (
                    <img
                      className={iconStyle}
                      alt="Drinks"
                      src="/ImageFolder/drink.png"
                    />
                  );
                }else {
                  return (
                    <img
                      className={iconStyle}
                      alt="La Carte"
                      src="/ImageFolder/la_carte.png"
                    />
                  );
                }
              })()}
            </div>
          </button>
        ))}
      </div>
      <div className="w-[85%] h-[100%]">
        {children.map((child) => {
          if (child.props.label === activeTab && child.props.label !== "La Carte") {
            return (
              <div key={child.props.label} className="w-full h-full">

                {/*HEADER OF TAB*/}
                <p className="ml-2 mt-2 2xl:text-5xl lg:text-4xl font-semibold">
                  {child.props.label}
                </p>

                {/*CONTENTS OF TAB*/}
                <div className="w-full 2xl:h-[625px] lg:h-[390px] pb-5 overflow-y-scroll">
                  <div className=" mt-3 mr-2 ml-2 grid grid-cols-3 grid-rows-auto gap-x-[2%] gap-y-[2%]">
                  {child.props.children}
                  </div>
                </div>
              </div>
            );
          }else if (child.props.label === activeTab && child.props.label === "La Carte") {
            return (
              <div key={child.props.label} className="w-full h-full">

                {/*HEADER OF TAB*/}
                <div className="ml-2 mt-2 flex items-end">
                  <p className="2xl:text-5xl lg:text-4xl font-semibold">{child.props.label}</p>
                  <p className="2xl:text-2xl lg:text-xl "> (Individual Sides or Entrees)</p>
                </div>

                {/*CONTENTS OF TAB*/}
                <div className="w-full 2xl:h-[625px] lg:h-[390px] pb-5 overflow-y-scroll ">
                  <div className=" mt-3 mr-2 ml-2 grid grid-cols-4 grid-rows-auto gap-x-[2%] gap-y-[2%]">
                  {child.props.children}
                  </div>
                </div>
              </div>
            );
          }
          return null;
        })}
      </div>
    </div>
  );
};

const KioskTab = ({ label, children }) => {
  return (
    <div label={label} className="hidden">
      {children}
    </div>
  );
};

export { KioskTabs, KioskTab };
