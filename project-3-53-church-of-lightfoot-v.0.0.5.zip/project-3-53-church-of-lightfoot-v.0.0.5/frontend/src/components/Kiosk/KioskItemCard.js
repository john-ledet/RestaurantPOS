import React, { useState } from "react";

import { KioskInfoLayout } from "./KioskInfoLayout.js";

const KioskItemCard = ({ onClick, item, picture, cardSize, infoStyle, nameSize, pictureSize, priceSize, messageStyle = '', spicySize, wokSize}) => {
  //console.log("This picture link is: ", picture);

  const [infoStatus, setInfoStatus] = useState(false);

  const openInfoModal = () => {
    setInfoStatus(true);
  };

  const closeInfoModal = () => {
    setInfoStatus(false);
  };

  const isWokSmart = () => {
    if(item.protein >= 8 && item.calories <= 300){
      return true;
    }else{
      return false; 
    }
  }

  return (
    <div>
      <div
        className={`
          ${cardSize} border shadow-sm shadow-black bg-white rounded-md 
          group hover:bg-red-500
          flex flex-col items-center flex-grow relative`}
        onClick={() => onClick(item)}
      >
        <button
          className={`${
            item.item_type === "DRINK"
              ? "opacity-0 cursor pointer-events-none"
              : ""
          }
         ${infoStyle}
        border border-black bg-white hover:bg-yellow-300
        flex items-center justify-center rounded-full`}
          onClick={(e) => {
            e.stopPropagation();
            openInfoModal();
          }}
        >
          i
        </button>
        <p className={`${nameSize} font-semibold group-hover:text-white text-center`}>
          {item.name}
        </p>
        <img
          src={picture}
          alt={item.name}
          className={`${pictureSize} mt-5 object-cover border-b group-hover:border-white group-hover:text-white`}
        />
        <p
          className={`${priceSize} font-semibold group-hover:text-white`}
        >
          ${item.price}
        </p>

        <div className={`${item.premium ? '' : 'opacity-0'} absolute w-full ${messageStyle} flex justify-center items-center bg-black`}>
          <p className="text-yellow-300">
            PREMIUM
          </p>
        </div>
        <div className={`${item.item_type === "SEASONAL" ? '' : 'opacity-0'} absolute w-full ${messageStyle} flex justify-center items-center bg-black`}>
          <p className="text-yellow-300">
            Limited-Time Offer
          </p>
        </div>

        <div className="absolute bottom-0 right-0 flex">
          <img src = "/ImageFolder/spicy_icon.png" className={`${!item.spicy ? 'hidden' : ''} ${spicySize} h-auto object-contain`}/>
          <img src = "/ImageFolder/wok_smart_icon.png" className={`${!isWokSmart() ? 'hidden' : ''} ${wokSize} h-auto object-contain`}/>
        </div>
      </div>
      <KioskInfoLayout
        infoStatus={infoStatus}
        item={item}
        closeInfo={closeInfoModal}
      />
    </div>
  );
};

const KioskMealCard = ({ onClick, item, picture }) => {
  const getCalories = () => {
    if (item.name === "Bowl") {
      return "280 - 1130 Calories";
    } else if (item.name === "Plate") {
      return "430 - 1640 Calories";
    } else {
      return "580 - 2150 Calories";
    }
  };

  const getMealInfo = () => {
    if (item.name === "Bowl") {
      return "Pick 1 Side and 1 Entree";
    } else if (item.name === "Plate") {
      return "Pick 1 Side and 2 Entrees";
    } else {
      return "Pick 1 Side and 3 Entrees";
    }
  };

  return (
    <button
      className="
        2xl:h-[550px] 2xl:w-[450px] h-[350px] w-[300px]
        border shadow-sm shadow-black bg-white rounded-md 
        hover:bg-red-500 hover:text-white
        flex flex-col items-center flex-grow"
      onClick={() => onClick(item)}
    >
      <p className="font-semibold 2xl:text-2xl text-lg h-[10%]">{item.name}</p>
      <img
        src={picture}
        alt={item.name}
        className="mt-5 w-[full] 2xl:h-[250px] h-[150px] object-cover border-b "
      />
      <p>{getCalories()}</p>
      <p className={`mt-10 h-[20%] font-semibold 2xl:text-2xl text-lg`}>
        ${item.price}
      </p>
      <p>{getMealInfo()}</p>
    </button>
  );
};

const BuildYourMealCard = ({ item, picture, isSelected, onAdd, onRemove = () => {}}) => {
  //console.log("This picture link is: ", picture);

  const [infoStatus, setInfoStatus] = useState(false);

  const openInfoModal = () => {
    setInfoStatus(true);
  };

  const closeInfoModal = () => {
    setInfoStatus(false);
  };

  const isWokSmart = () => {
    if(item.protein >= 8 && item.calories <= 300){
      return true;
    }else{
      return false; 
    }
  }

  return (
    <div>
      <div
        className={`${isSelected ? 'bg-red-500': 'bg-white'}
            2xl:h-[550px] 2xl:w-[450px] h-[260px] w-[200px]
            border shadow-sm shadow-black rounded-md 
            hover:border-red-500
            flex flex-col items-center flex-grow relative`}
            onClick={() => {
              if(isSelected && item.item_type === "SIDE"){
                onRemove(item);
              }else if (!isSelected && item.item_type === "SIDE"){
                onAdd(item);
              }else{
                onAdd(item); 
              }
            }}
      >
        <button
          className={`
          w-[13%] h-[10%] absolute top-0.5 left-1 p-2 
          border border-black text-sm font-semibold bg-white hover:bg-yellow-300
          flex items-center justify-center rounded-full`}
          onClick={(e) => {
            e.stopPropagation();
            openInfoModal();
          }}
        >
          i
        </button>

        <p className={`${isSelected ? 'text-white': ''} font-semibold 2xl:text-2xl text-md h-[5%] w-[65%] text-center`}>
          {item.name}
        </p>

        <img
          src={picture}
          alt={item.name}
          className="mt-5 w-[full] 2xl:h-[250px] h-[150px] object-cover border-b group:text-white"
        />

        <div className={`${item.premium ? '' : 'opacity-0'} absolute w-full h-[7%] flex justify-center items-center bottom-16  bg-black`}>
          <p className="text-yellow-300 font-semibold text-sm">
            PREMIUM +${item.price}
          </p>
        </div>
        <div className={`${item.item_type === "SEASONAL" ? '' : 'opacity-0'} absolute w-full h-[7%] flex justify-center items-center bottom-16 bg-black`}>
          <p className="text-yellow-300 font-semibold text-sm">
          {item.price === 0 ? 'Limited-Time Offer' : `Limited-Time Offer $${item.price}`}
          </p>
        </div>

        <p className={`${isSelected ? 'text-white': ''} mt-3`}>{item.calories} Cal</p>

        <div className="absolute bottom-0 right-0 flex">
          <img src = "/ImageFolder/spicy_icon.png" className={`${!item.spicy ? 'hidden' : ''} w-[15%] h-auto object-contain`}/>
          <img src = "/ImageFolder/wok_smart_icon.png" className={`${!isWokSmart() ? 'hidden' : ''} w-[17%] h-auto object-contain`}/>
        </div>

      </div>
      <KioskInfoLayout
        infoStatus={infoStatus}
        item={item}
        closeInfo={closeInfoModal}
      />
    </div>
  );
};

export { KioskItemCard, BuildYourMealCard, KioskMealCard};
