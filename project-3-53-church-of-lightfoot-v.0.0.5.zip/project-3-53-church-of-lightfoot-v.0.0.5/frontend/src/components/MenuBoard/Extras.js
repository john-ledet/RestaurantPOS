import React from "react";

const Extras = ({ appetizers, drinks }) => {
  const extrasImages = {
    "Chicken Egg Roll": "/ImageFolder/chicken_egg_roll.png",
    "Veggie Egg Roll": "/ImageFolder/veggie_egg_roll.png",
    "Cream Cheese Rangoon": "/ImageFolder/cream_cheese_rangoon.png",
  };

  return (
    <section className="section extras">
      <h2 className="section-title">Extras</h2>
      <div className="extra-category">
        <h3 className="food-headers">Appetizers</h3>
        <div className = 'extra-container'>
          {appetizers.map((app) => (
            <div key={app.menu_item_id} className="extra-option">
              <div className={`${app.allergens === "None" ? 'hidden' : ''}`}>
                <img src = '/ImageFolder/warning_panda.png' className='allergen-icon'/>
              </div>
              <img
                src={extrasImages[app.name]}
                alt={extrasImages[app.name]}
                className="entree-image"
              />
              {app.name} - ${parseFloat(app.price).toFixed(2)}<span className="calorie-info">{app.calories} Calories</span>
            </div>
          ))}
        </div>
      </div>
      <div className="extra-category">
        <h3 className="food-headers">Drinks</h3>
        <div className = "drink-container">
          {drinks.map((drink) => (
            <div key={drink.menu_item_id} className="extra-option">
              {drink.name} - ${parseFloat(drink.price).toFixed(2)}
            </div>
          ))}  
        </div>
      </div>
    </section>
  );
};

export default Extras;
