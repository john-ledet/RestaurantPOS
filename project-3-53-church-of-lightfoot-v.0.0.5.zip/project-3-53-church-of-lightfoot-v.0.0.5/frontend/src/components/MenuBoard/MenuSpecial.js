import React, { useState, useEffect } from "react";

const SeasonalItems = ({ items }) => {
  return (
      <section className="section seasonal-items">
      <h2 className="section-title">Seasonal Items and Favorites</h2>
      <h3 className= "section-title">Seasonal Items</h3>
      <div>
        {items.map((item) => (
          <div key={item.menu_item_id} className="special">
            {item.name} - ${parseFloat(item.price).toFixed(2)}
          </div>
        ))}
      </div>
      <h4 className = "section-title">Favorites</h4>
      <div></div>
    </section>  
  );
};

export default SeasonalItems;
