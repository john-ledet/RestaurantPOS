import express from 'express';
const InventoryRouter = express.Router();

import client from '../Database.js';

InventoryRouter.get('/', async (req, res) => {
  try {
    const results = await client.query(`
      SELECT ingredient_id, name, quantity_stock, unit, min_threshold, max_threshold, restock_quantity, current_price
      FROM inventory
      ORDER BY ingredient_id ASC
    `);
    res.json(results.rows);
  } catch (err) {
    console.error("Error fetching inventory data:", err.message);
    res.status(500).send('Error fetching inventory data');
  }
});

InventoryRouter.get('/orders', async (req, res) => {
  try {
    const results = await client.query(`
      SELECT * FROM menu_items_inventory
      ORDER BY menu_item_id ASC
    `);
    res.json(results.rows);
  } catch (err) {
    console.error("Error fetching menu item inventory data:", err.message);
    res.status(500).send('Error fetching menu item inventory data');
  }
});

InventoryRouter.get('/name', async (req, res) => {
  const { ingredient } = req.query;
  try {
    const results = await client.query(`SELECT name, unit FROM inventory WHERE ingredient_id=${ingredient}`);
    res.json(results.rows);
  } catch (err) {
    console.error("Error fetching inventory names:", err.message);
    res.status(500).send('Error fetching inventory names');
  }
});

export default InventoryRouter;
