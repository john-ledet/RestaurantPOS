import express from "express";
const UserRouter = express.Router();

import client from "../Database.js";

UserRouter.get("/:userId", async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await client.query("SELECT * FROM user_roles WHERE user_id = $1", [userId]);

    console.log(result);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

UserRouter.post("/", async (req, res) => {
  try {
    const { userId, role = 1, name } = req.body;

    if (role < 0 || role > 4) {
      return res.status(400).json({ message: "Invalid role. Must be between 0-4" });
    }

    const existingUser = await client.query("SELECT * FROM user_roles WHERE user_id = $1", [userId]);

    if (existingUser.rows.length > 0) {
      return res.json(existingUser.rows[0]);
    }

    const newUser = await client.query("INSERT INTO user_roles (user_id, role, name) VALUES ($1, $2, $3) RETURNING *", [userId, role, name]);

    res.status(201).json(newUser.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

export default UserRouter;
