import express from 'express'
const KioskRouter = express.Router()

import client from "../Database.js";

KioskRouter.get('/', async (req, res) => {
    try {
      const results = await client.query(`
      SELECT mi.menu_item_id, 
      mi.name, mi.item_type, mi.price, 
      COALESCE(mii.calories, 0) AS calories, 
      COALESCE(mii.protein, 0) AS protein, 
      COALESCE(mii.carbohydrate, 0) AS carbohydrate, 
      COALESCE(mii.saturated_fat, 0) AS saturated_fat, 
      COALESCE(mii.spicy, false) AS spicy, 
      COALESCE(mii.premium, false) AS premium,
      COALESCE(mii.allergens, 'None') AS allergens 
      FROM menu_items mi 
      LEFT JOIN menu_items_info mii 
      ON mii.menu_item_id = mi.menu_item_id
      ORDER BY mi.menu_item_id ASC
        `);
      res.json(results.rows);
    } catch (err) {
      console.error(err.message);
    }
});

KioskRouter.get('/nextorder', async (req, res) => {
  try{
    const result = await client.query (`SELECT order_id from orders ORDER BY order_id desc LIMIT 1`);
    if (result.rows.length > 0) {
      const orderId = result.rows[0].order_id;
      res.json({ order_id: orderId });  // Send the order_id as a JSON response
    } else {
      res.status(404).json({ message: "No orders found" }); // Handle case if no orders exist
    }
  } catch (err){
    console.error(err.message);
  }
})

KioskRouter.post('/database', async (req, res) => {
  const {total, order, groupedOrder, rating} = req.body;
  
  const timestamp = new Date();
  const currentTimeFormatted = timestamp.toLocaleString();

  let latest_order_query = await client.query(`SELECT order_id from orders ORDER BY order_id desc LIMIT 1`)
  let latest_order_item_query = await client.query(`SELECT menu_order_id from menu_orders ORDER BY menu_order_id desc LIMIT 1`)
  let latest_kitchen_item_query = await client.query(`SELECT menu_order_id from currentorders ORDER BY menu_order_id desc LIMIT 1`)

  const latest_order_id = latest_order_query.rows[0]['order_id']
  const latest_order_item_id = latest_order_item_query.rows[0]['menu_order_id']
  let latest_kitchen_item_id = 0; 

  //If no rows are retrieved from menu_order_id(currentorders) start at 1 
  if (latest_kitchen_item_query.rows.length > 0) {
    latest_kitchen_item_id = latest_kitchen_item_query.rows[0]['menu_order_id'];
  }

  const new_order_id = latest_order_id + 1
  let new_order_item_id = latest_order_item_id + 1
  let new_kitchen_item_id = latest_kitchen_item_id + 1

  // insert into order table
  await client.query(`INSERT INTO orders (order_id, employee_id, timestamp, total, review, reportable) VALUES ($1, 0, $2, $3, $4, true)`, [new_order_id, timestamp, parseFloat(total), parseInt(rating)]);
  Object.keys(order).map(key => {
    let items = order[key]

    items.map(async item => {
      await client.query(`INSERT INTO menu_orders (menu_order_id, order_id, menu_item_id, quantity) VALUES ($1, $2, $3, 1)`, [new_order_item_id, new_order_id, parseInt(item['menu_item_id']) ])
      new_order_item_id += 1
    })
  })
  for(const item of groupedOrder){
    //console.log(groupedOrder);
    let itemNumGroup = item.groupNum;
    if(item.type === "MEAL"){
      //console.log("This is group: ", item.groupNum)
      //console.log("I am the meal: ", item.meal.name); 
      await client.query(`INSERT INTO currentorders (menu_order_id, order_id, menu_item_id, quantity, order_created, itemgroup) VALUES ($1, $2, $3, 1, $4, $5)`, 
        [new_kitchen_item_id, new_order_id, parseInt(item.meal.menu_item_id), currentTimeFormatted, parseInt(itemNumGroup)]
      )
      new_kitchen_item_id += 1; 
      for(const side of item.sides){
        await client.query(`INSERT INTO currentorders (menu_order_id, order_id, menu_item_id, quantity, order_created, itemgroup) VALUES ($1, $2, $3, 1, $4, $5)`, 
          [new_kitchen_item_id, new_order_id, parseInt(side.menu_item_id), currentTimeFormatted, parseInt(itemNumGroup)]
        )
        new_kitchen_item_id += 1; 
        //console.log("My SIDE From gorup ",itemNumGroup, " is ", side.name);
      }

      for(const entree of item.entrees){
        await client.query(`INSERT INTO currentorders (menu_order_id, order_id, menu_item_id, quantity, order_created, itemgroup) VALUES ($1, $2, $3, 1, $4, $5)`, 
          [new_kitchen_item_id, new_order_id, parseInt(entree.menu_item_id), currentTimeFormatted, parseInt(itemNumGroup)]
        )
        new_kitchen_item_id += 1;
        //console.log("My ENTREE From gorup ",itemNumGroup, " is ", entree.name);
      }
    }else if (item.type === "LACARTE"){

      await client.query(`INSERT INTO currentorders (menu_order_id, order_id, menu_item_id, quantity, order_created, itemgroup) VALUES ($1, $2, $3, 1, $4, $5)`, 
        [new_kitchen_item_id, new_order_id, parseInt(item.size.menu_item_id), currentTimeFormatted, parseInt(itemNumGroup)]
      )
      new_kitchen_item_id += 1;

      await client.query(`INSERT INTO currentorders (menu_order_id, order_id, menu_item_id, quantity, order_created, itemgroup) VALUES ($1, $2, $3, 1, $4, $5)`, 
        [new_kitchen_item_id, new_order_id, parseInt(item.item.menu_item_id), currentTimeFormatted, parseInt(itemNumGroup)]
      )
      new_kitchen_item_id += 1;

    }else{
      await client.query(`INSERT INTO currentorders (menu_order_id, order_id, menu_item_id, quantity, order_created, itemgroup) VALUES ($1, $2, $3, 1, $4, $5)`, 
        [new_kitchen_item_id, new_order_id, parseInt(item.item.menu_item_id), currentTimeFormatted, parseInt(itemNumGroup)]
      )
      new_kitchen_item_id += 1; 
    }   
  }

  res.sendStatus(200)
})

KioskRouter.put('/updateInventory', async (req, res) => {
  const { order} = req.body;
  let inventoryquery = `SELECT mi.menu_item_id,
                        mi.ingredient_id,
                        mi.quantity_used,
                        inv.name,
                        inv.quantity_stock 
                        FROM menu_items_inventory mi
                        JOIN inventory inv
                        ON mi.ingredient_id = inv.ingredient_id
                        WHERE mi.menu_item_id = $1`

  let updateQuery = `UPDATE inventory
                      SET quantity_stock = GREATEST(quantity_stock - $1, 0)
                      WHERE ingredient_id = $2`

  Object.keys(order).map(key => {
    if(key === "SIDE" || key === "ENTREE" || key === "LACARTE" ){
      let items = order[key]; 
      items.map(async (item, index) => {
        let inventoryData = ''; 
        let amountToRemove = 0.0; 
        if(item.item_type === "LACARTE"){
          let carteItem = order["CARTEITEMS"][index]; 
          inventoryData = await client.query(inventoryquery,[carteItem.menu_item_id]);
          inventoryData.rows.map(async (ingredient) => {
            if(item.name.includes("Small")){
              amountToRemove = ingredient.quantity_used
            }else if (item.name.includes("Medium")){
              amountToRemove = ingredient.quantity_used * 1.5;
            }else{
              amountToRemove = ingredient.quantity_used * 2;
            }
            await client.query(updateQuery,[amountToRemove, ingredient.ingredient_id]);
          })
        }else{
          inventoryData = await client.query(inventoryquery,[item.menu_item_id]); 
          inventoryData.rows.map(async (ingredient) => {
            if(item.item_type === "SIDE"){
              amountToRemove = ingredient.quantity_used * 0.5; 
            }else{
              amountToRemove = ingredient.quantity_used; 
            } 
            await client.query(updateQuery,[amountToRemove, ingredient.ingredient_id]);
          })
        }
      })
    }
  })

  res.sendStatus(200)
})

export default KioskRouter; 