import express from 'express'
const ItemsRouter = express.Router()

import client from '../Database.js';
import { getAllItemsSQL } from '../items_database_commands.js';


ItemsRouter.get('/', async (req, res) => {
  try {
    const results = await client.query(getAllItemsSQL);
    res.json(results.rows);
  } catch (err) {
    console.error(err.message);
  }
})

ItemsRouter.get('/:name', async (req, res) => {
  const { name } = req.params;
  try {
    const results = await client.query(`SELECT * FROM menu_items WHERE name = $1`, [name]);
    res.json(results.rows);
  } catch (err) {
    console.error(err.message);
  }
})

ItemsRouter.post('/', async (req, res) => {
  const {total, employee_id, order} = req.body;
  const timestamp = new Date();

  let latest_order_query = await client.query(`SELECT order_id from orders ORDER BY order_id desc LIMIT 1`)
  let latest_order_item_query = await client.query(`SELECT menu_order_id from menu_orders ORDER BY menu_order_id desc LIMIT 1`)

  const latest_order_id = latest_order_query.rows[0]['order_id']
  let latest_item_id = latest_order_item_query.rows[0]['menu_order_id']

  const new_order_id = latest_order_id + 1
  latest_item_id += 1

  // insert into order table
  await client.query(`INSERT INTO orders (order_id, employee_id, timestamp, total) VALUES ($1, $2, $3, $4)`, [new_order_id, parseInt(employee_id), timestamp, parseFloat(total)]);
  Object.keys(order).map(key => {
    let items = order[key]

    items.map(async item => {
      await client.query(`INSERT INTO menu_orders (menu_order_id, order_id, menu_item_id, quantity) VALUES ($1, $2, $3, 1)`, [latest_item_id, new_order_id, parseInt(item['menu_item_id']) ])
      latest_item_id += 1
    })
  })

  res.sendStatus(200)
})

  ItemsRouter.delete('/:id', async (req, res) => {
    const { id } = req.params;
    try {
      await client.query(`DELETE FROM menu_items WHERE menu_item_id = $1`, [id]);
      res.sendStatus(200);
    } catch (err) {
      console.error("Error deleting item:", err.message);
      res.status(500).json({ error: "Failed to delete item" });
    }
  })

  ItemsRouter.post('/', async (req, res) => {
    const { id, name, type, price } = req.params;
    try {
      await client.query(
        'INSERT INTO menu_items (menu_item_id, name, item_type, price) VALUES ($1, $2, $3, $4)',
        [parseInt(id), name, type, parseFloat(price)]
      );    res.sendStatus(200);
    } catch (err) {
      console.error("Error adding items:", err.message);
      res.status(500).json({ error: "Failed to add item"});
    }
  })

export default ItemsRouter