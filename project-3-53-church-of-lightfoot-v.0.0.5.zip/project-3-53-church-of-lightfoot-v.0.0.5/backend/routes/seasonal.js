import express from "express";
const SeasonalsRouter = express.Router();

import client from "../Database.js";
import { isPIN } from "../util/helperFunctions.js";

SeasonalsRouter.get("/", async (req, res) => {
    try {
      const results = await client.query(
        `SELECT * FROM menu_items WHERE item_type = 'SPECIAL'`
      );
      res.json(results.rows);
    } catch (err) {
      console.error(err.message);
    }
  });

  SeasonalsRouter.post("/add", async (req, res) => {
    const { name, price } = req.body;

    // Validate input
    if (!name || !price) {
        res.sendStatus(400); // Bad Request
        return;
    }

    try {
        const highIDResult = await client.query("SELECT MAX(menu_item_id) AS max FROM menu_items");
        const highID = highIDResult.rows[0].max || 0;

        await client.query(
            "INSERT INTO menu_items (menu_item_id, name, item_type, price) VALUES ($1, $2, 'SPECIAL', $3)",
            [highID + 1, name, price]
        );

        console.log("Added seasonal item");
        res.sendStatus(200); 
    } catch (err) {
        console.error("Error adding seasonal item:", err);
        res.sendStatus(500); 
    }
});

SeasonalsRouter.delete("/:id", async (req, res) => {
    const { id } = req.params;
    console.log("Removing seasonal #", id, "...");
  
    await client.query("DELETE FROM menu_items WHERE menu_item_id = $1", [id]);
  
    console.log("Seasonal removal success!");
    res.sendStatus(200);
  });

export default SeasonalsRouter;