import express from "express";
const EmployeesRouter = express.Router();

import client from "../Database.js";
import { isPIN } from "../util/helperFunctions.js";

EmployeesRouter.get("/", async (req, res) => {
  try {
    const results = await client.query(
      `SELECT * FROM employee ORDER BY employee_id ASC`
    );
    res.json(results.rows);
  } catch (err) {
    console.error(err.message);
  }
});

EmployeesRouter.post("/add", async (req, res) => {
  const { first_name, last_name, position, pin_id } = req.body;
  // Check if any fields were blank
  if (
    first_name === "" ||
    last_name  === "" ||
    position   === "" ||
    !isPIN(pin_id)
  ) { 
    res.sendStatus(400);
    return;
  }
  let high_ID_query = await client.query(
    `SELECT MAX(employee_id) FROM employee`
  );
  const high_ID = high_ID_query.rows[0]["max"];

  await client.query(
    "INSERT INTO employee (employee_id, first_name, last_name, position, is_active, pin_id) VALUES ($1, $2, $3, $4, true, $5)",
    [high_ID + 1, first_name, last_name, position, pin_id]
  );

  console.log("Added employee");
  res.sendStatus(200);
});

EmployeesRouter.delete("/:id", async (req, res) => {
  const { id } = req.params;
  console.log("Removing employee #", id, "...");

  await client.query("DELETE FROM employee WHERE employee_id = $1", [id]);

  console.log("Employee removal success!");
  res.sendStatus(200);
});

export default EmployeesRouter;
