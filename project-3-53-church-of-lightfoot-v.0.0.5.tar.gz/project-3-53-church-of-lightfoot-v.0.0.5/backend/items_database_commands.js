// Item related database commands
export const getAllItemsSQL = `SELECT * FROM menu_items`;