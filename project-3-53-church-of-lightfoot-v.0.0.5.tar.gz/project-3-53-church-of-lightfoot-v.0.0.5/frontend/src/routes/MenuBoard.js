import React, { useEffect, useState } from 'react';
import './MenuBoard.css';
import MenuHeader from '../components/MenuBoard/MenuHeader';
import MenuMealOptions from '../components/MenuBoard/MenuMealOptions';
import PickSide from '../components/MenuBoard/PickSide';
import PickEntree from '../components/MenuBoard/PickEntree';
import Extras from '../components/MenuBoard/Extras';
import MenuSpecial from '../components/MenuBoard/MenuSpecial';
import { executeGet } from '../util/Requests';

export const MenuBoard = () => {
    const [menuItems, setMenuItems] = useState([]);

    const fetchMenuItems = async () => {
        try {
            const data = await executeGet("kiosk", {}, "GET");
            console.log("Fetched data:", data);
            setMenuItems(data);
        } catch (error) {
            console.error("Error fetching menu items:", error);
        }
    };

    // Fetch menu items on initial render
    useEffect(() => {
        fetchMenuItems();
        return () => setMenuItems([]); // Cleanup function
    }, []);
    return (
        <div className="menu-board">
            <MenuHeader />
            <MenuMealOptions items={menuItems.filter(item => item.item_type === "MEAL")} />
            <MenuSpecial items={menuItems.filter(item => item.item_type === "SPECIAL")} />
            <PickEntree items={menuItems.filter(item => item.item_type === "ENTREE")} />
            <PickSide items={menuItems.filter(item => item.item_type === "SIDE")} />
            <Extras
                appetizers={menuItems.filter(item => item.item_type === "APPETIZER")}
                drinks={menuItems.filter(item => item.item_type === "DRINK")}
            />
        </div>
    );
};

export default MenuBoard;
