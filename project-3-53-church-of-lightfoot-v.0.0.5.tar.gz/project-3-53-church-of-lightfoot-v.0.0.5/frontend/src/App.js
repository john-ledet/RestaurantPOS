import "./App.css";
import { PointOfSale } from "./routes/PointOfSale";
import { MenuBoard } from "./routes/MenuBoard";
import { Manager } from "./routes/Manager";
import { KitchenView } from "./routes/KitchenView";

import { KioskStart } from "./routes/KioskRoute/KioskStart";
import { KioskOrder } from "./routes/KioskRoute/KioskOrder";
import { Index } from "./routes/Index";
import { CompletedView } from "./routes/CompletedView";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { UserProvider } from './context/UserContext';

function App() {
  return (
    <UserProvider>
      <BrowserRouter>
      <Routes>
        <Route path="/">
          <Route index element={<Index />} />
        </Route>
        <Route path="/POS">
          <Route index element={<PointOfSale />} />
        </Route>
        <Route path="/MenuBoard">
          <Route index element={<MenuBoard />} />
        </Route>
        <Route path="/manager">
          <Route index element={<Manager />} />
        </Route>
        <Route path="/KioskStart">
          <Route index element={<KioskStart />} />
        </Route>
        <Route path="/KioskOrder">
          <Route index element={<KioskOrder />} />
        </Route>
        <Route path="/KitchenView">
          <Route index element={<KitchenView />} />
        </Route>
        <Route path="/CompletedView">
          <Route index element={<CompletedView />} />
        </Route>
      </Routes>
    </BrowserRouter>
    </UserProvider>
  );
}

export default App;
