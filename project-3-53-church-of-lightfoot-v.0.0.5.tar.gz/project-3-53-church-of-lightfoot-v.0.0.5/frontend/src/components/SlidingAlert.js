import React, { useState, useEffect } from "react";

const SlidingAlert = ({ lowStockItems }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const formatName = (name) =>
    name
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");

  useEffect(() => {
    if (lowStockItems.length > 1) {
      const interval = setInterval(() => {
        setIsAnimating(true);

        setTimeout(() => {
          setCurrentIndex((prevIndex) => (prevIndex + 1) % lowStockItems.length);
          setIsAnimating(false); // Reset animation
        }, 500); // Animation duration
      }, 5000); // Display time for each alert

      return () => clearInterval(interval);
    }
  }, [lowStockItems]);

  if (!lowStockItems.length) {
    // Render a static message when there are no low-stock items
    return (
      <div className="h-12 w-64 flex items-center justify-center text-green-600 text-lg font-semibold">
        ✅ All stocks are sufficient
      </div>
    );
  }

  const currentAlert = formatName(lowStockItems[currentIndex]?.name || "");
  const nextAlert =
    formatName(lowStockItems[(currentIndex + 1) % lowStockItems.length]?.name);

  return (
    <div className="relative h-12 w-64 overflow-hidden">
      {/* Current Alert */}
      <div
        className={`absolute top-0 left-0 w-full h-full flex items-center justify-center text-red-500 text-lg font-semibold transition-transform duration-500 ${
          isAnimating ? "translate-y-full" : "translate-y-0"
        }`}
      >
        ⚠ {currentAlert} Stock Low
      </div>

      {/* Next Alert */}
      <div
        className={`absolute -top-full left-0 w-full h-full flex items-center justify-center text-red-500 text-lg font-semibold transition-transform duration-500 ${
          isAnimating ? "translate-y-0" : "-translate-y-full"
        }`}
      >
        ⚠ {nextAlert} Stock Low
      </div>
    </div>
  );
};

export default SlidingAlert;