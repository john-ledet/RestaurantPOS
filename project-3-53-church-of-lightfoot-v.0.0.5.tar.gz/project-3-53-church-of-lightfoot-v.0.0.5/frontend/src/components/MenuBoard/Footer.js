import React, { useEffect, useState } from "react";
import "../../routes/MenuBoard.css";
import { ReactComponent as MoonSvg } from "./svgs/dark_mode_24dp_E8EAED_FILL1_wght400_GRAD0_opsz24.svg";
import { ReactComponent as CloudSvg } from "./svgs/filter_drama_24dp_E8EAED_FILL1_wght400_GRAD0_opsz24.svg";
import { ReactComponent as SunSvg} from "./svgs/brightness_5_24dp_E8EAED_FILL1_wght400_GRAD0_opsz24.svg";

const Footer = () => {
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState(null);
  const [time, setTime] = useState(new Date().toLocaleTimeString());

  const latitude = 30.601389;
  const longitude = -96.3344;

  const isDayTime = () => {
    const hours = new Date().getHours();
    return hours >= 6 && hours < 18; // Daytime is between 6:00 AM and 6:00 PM
  };

  useEffect(() => {
    // Fetch the forecast URL using the point lookup API
    const fetchWeather = async () => {
      try {
        // Step 1: Get the forecast URL
        const pointResponse = await fetch(
          `https://api.weather.gov/points/${latitude},${longitude}`
        );
        if (!pointResponse.ok) throw new Error("Failed to fetch location data");

        const pointData = await pointResponse.json();
        const forecastUrl = pointData.properties.forecast;

        // Step 2: Use the forecast URL to get the weather data
        const forecastResponse = await fetch(forecastUrl);
        if (!forecastResponse.ok)
          throw new Error("Failed to fetch forecast data");

        const forecastData = await forecastResponse.json();
        const currentPeriod = forecastData.properties.periods[0]; // Get the current period (today's forecast)

        setWeather(currentPeriod);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchWeather();
  }, [latitude, longitude]);

  setInterval(() => {
    setTime(new Date().toLocaleTimeString());
  }, 1000);

  // Conditional rendering to avoid null errors
  if (error) {
    return <div className="error">Error: {error}</div>;
  }

  if (!weather) {
    return <div className="loading">Loading weather data...</div>;
  }

  return (
    <div className={`weather-widget ${isDayTime() ? "day" : "night"}`}>
      {isDayTime() ? (
        <SunSvg className="sun" />
      ) : (
        <MoonSvg className="moon" />
      )}      
    <div className="cloud-container">
        <CloudSvg className="cloud" />
      </div>
      <div className="temperature">
        Temperature: {weather.temperature}°{weather.temperatureUnit}
      </div>
      <div className="weather">{weather.shortForecast} </div>
      <div className="low-high">Time: {time}</div>
    </div>
  );
};

export default Footer;
