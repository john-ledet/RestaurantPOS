const Allergy = () => (
    <div className = "allergen"> 
        <img src = '/ImageFolder/warning_panda.png' className = 'allergy-image'></img>
        <div className="allergy-text">Allergens: sesame, soybeans, wheat, milk, eggs</div>
    </div>
);

export default Allergy;