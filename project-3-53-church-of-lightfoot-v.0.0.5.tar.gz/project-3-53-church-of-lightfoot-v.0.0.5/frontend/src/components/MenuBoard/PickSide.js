import React from "react";

const PickSide = ({ items }) => {
  const sideImages = {
    "Fried Rice": "/ImageFolder/fried_rice.png",
    "Chow Mein": "/ImageFolder/chow_mein.png",
    "Super Greens": "/ImageFolder/super_greens.png",
    "White Rice": "/ImageFolder/white_rice.png",
  };

  return (
    <section className="section pick-side">
      <h2 className="section-title">3. Pick a Side</h2>
      <div className = "side-container">
        {items.map((item) => (
          <div key={item.menu_item_id} className="side-option">
            <img
              className="entree-image"
              alt={sideImages[item.name]}
              src={sideImages[item.name]}
            />
            {item.name}<span className="calorie-info">{item.calories} Calories</span>
            <div className={`${item.allergens === "None" ? 'hidden' : ''}`}>
                <img src = '/ImageFolder/warning_panda.png' className='allergen-icon'/>
              </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default PickSide;
