import React, { useEffect, useState } from "react";
import StarRating from "./StarRating";

export const KioskCheckout = ({
  onClose,
  onCheckout,
  deleteItem,
  currentOrder,
  currentTotal,
  setRating,
}) => {
  const buttonStyle =
    "w-[5%] h-[90%] text-bold text-lg bg-white hover:bg-red-500 border border-black flex justify-center items-center";
  const mainItemStyle = "w-[70%] h-full flex items-center";
  const priceStyle = "w-[10%] h-full";

  const [showStarRating, setShowStarRating] = useState(false);

  function parseSides(item, index) {
    const sideIndex = index * 2;
    return [
      currentOrder["SIDE"][sideIndex],
      currentOrder["SIDE"][sideIndex + 1],
    ];
  }

  function parseEntrees(item, index) {
    let indexCounter = 0;
    for (let i = 0; i < index; i++) {
      if (currentOrder["MEAL"][i].name === "Bowl") {
        //console.log("I have hit a bowl");
        indexCounter += 1;
      } else if (currentOrder["MEAL"][i].name === "Plate") {
        //console.log("I have hit a plate");
        indexCounter += 2;
      } else {
        //console.log("I have hit a Bigger Plate");
        indexCounter += 3;
      }
    }

    if (item.name === "Bowl") {
      return [currentOrder["ENTREE"][indexCounter]];
    } else if (item.name === "Plate") {
      return [
        currentOrder["ENTREE"][indexCounter],
        currentOrder["ENTREE"][indexCounter + 1],
      ];
    } else {
      return [
        currentOrder["ENTREE"][indexCounter],
        currentOrder["ENTREE"][indexCounter + 1],
        currentOrder["ENTREE"][indexCounter + 2],
      ];
    }
  }

  const parseCarteItems = (index) => {
    return currentOrder["CARTEITEMS"][index]; 
  }

  const handleRatingSubmit = (rating) => {
    console.log("Submitted Rating:", rating);
    setRating(parseInt(rating));
  };

  const handleStarRatingClose = () => {
    setShowStarRating(false);
    onCheckout();
  };

  return (
    <div className="w-full h-full flex flex-col font-sans font-semibold">
      {/*HEADER*/}
      <div className="w-full h-[5%] bg-red-500 text-white flex justify-center items-center rounded-t-lg 2xl:text-xl lg:text-md">
        Checkout Area
      </div>

      {/*REVIEW SECTION */}
      <div className="w-full h-[90%] flex flex-col items-center overflow-auto">
        {Object.keys(currentOrder).map((itemType) => {
          if (itemType !== "SIDE" && itemType !== "ENTREE" && itemType !== "CARTEITEMS") {
            return (
              <div key={itemType} className="w-full flex flex-col">
                {currentOrder[itemType].map((item, index) => {
                  const uniqueKey = `${item.name}-${index}`;
                  if (itemType === "MEAL") {
                    const sides = parseSides(item, index);
                    const entrees = parseEntrees(item, index);
                    //console.log("This MEAL has these SIDES", sides);
                    //console.log("This MEAL has these ENTREES", entrees);
                    return (
                      <div
                        key={uniqueKey}
                        className="w-full flex flex-col items-center mt-1 border-b border-black"
                      >
                        <div className="w-full flex justify-center items-center gap-2 ">
                          <button
                            className={buttonStyle}
                            onClick={() => deleteItem(item, index)}
                          >
                            X
                          </button>
                          <p className={mainItemStyle}>{item.name}</p>
                          <p className={priceStyle}>${item.price}</p>
                        </div>
                        <div className="w-full">
                          <div>
                            {sides.map((sideItem) => (
                              <div className="flex gap-1">
                                <div className="ml-[13%] w-[70%]">
                                  • 1/2 {sideItem.name}
                                </div>
                                <p
                                  className={`${
                                    Math.abs(sideItem.price) < 1e-10
                                      ? "opacity-0"
                                      : ""
                                  }`}
                                >
                                  ${sideItem.price}
                                </p>
                              </div>
                            ))}
                          </div>
                          <div>
                            {entrees.map((entreeItem) => (
                              <div className="flex gap-1">
                                <div className="ml-[13%] w-[70%]">
                                  • {entreeItem.name}
                                </div>
                                <p
                                  className={`${
                                    Math.abs(entreeItem.price) < 1e-10
                                      ? "opacity-0"
                                      : ""
                                  }`}
                                >
                                  ${entreeItem.price}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  }else if(itemType === "LACARTE"){
                    const carteItem = parseCarteItems(index);
                    return (
                      <div
                        key={uniqueKey}
                        className="w-full flex flex-col items-center mt-1 border-b border-black"
                      >
                        <div className="w-full flex justify-center items-center gap-2 ">
                          <button
                            className={buttonStyle}
                            onClick={() => deleteItem(item, index)}
                          >
                            X
                          </button>
                          <p className={mainItemStyle}>{item.name}</p>
                          <p className={priceStyle}>${item.price}</p>
                        </div>
                        <div className="w-full">
                          <div className="flex gap-1">
                            <div className="ml-[13%] w-[70%]">
                              • {carteItem.name}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  }else{
                    return (
                      <div
                        key={uniqueKey}
                        className="w-full flex justify-center mt-1 gap-2 border-b border-black"
                      >
                        <button
                          className={buttonStyle}
                          onClick={() => deleteItem(item, index)}
                        >
                          X
                        </button>
                        <p className={mainItemStyle}>{item.name}</p>
                        <p className={priceStyle}>${item.price}</p>
                      </div>
                    );
                  }
                })}
              </div>
            );
          } else {
            return null;
          }
        })}
        <div className=" w-full h-[5%] flex">
          <p className="relative left-[77%]">
            Total: ${parseFloat(currentTotal).toFixed(2)}
          </p>
        </div>
      </div>

      {/*FOOTER*/}
      <div className="w-full h-[5%] p-4 bg-red-500 flex justify-between items-center rounded-b-lg 2xl:text-xl lg:text-md">
        <button
          className="bg-white text-black rounded-md 2xl:w-[20%] lg:w-[20%] hover:bg-black hover:text-yellow-300"
          onClick={() => onClose()}
        >
          Go Back
        </button>
        <button
          className="bg-white text-black rounded-md 2xl:w-[20%] lg:w-[20%] hover:bg-black hover:text-yellow-300"
          onClick={() => setShowStarRating(true)}
        >
          Checkout
        </button>

        {showStarRating && (
          <StarRating
            onClose={handleStarRatingClose}
            onSubmit={handleRatingSubmit}
          />
        )}
      </div>
    </div>
  );
};
