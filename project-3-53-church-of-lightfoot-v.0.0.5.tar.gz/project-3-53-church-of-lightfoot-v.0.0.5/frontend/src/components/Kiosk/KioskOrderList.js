import React, { useState, useEffect } from "react";
import KioskOrder from "./KioskOrder";
import { executeGet, executeDelete } from "../../util/Requests";

function KioskOrderList() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const data = await executeGet("kioskorders");
        console.log("Fetched orders:", data); // Debugging log
        setOrders(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error("Error fetching orders:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();

    const intervalId = setInterval(fetchOrders, 5000);
    return () => clearInterval(intervalId);
  }, []);

  const handleComplete = async (orderId) => {
    try {
      await executeDelete(`kioskorders/${orderId}`);
      setOrders((prevOrders) =>
        prevOrders.filter((order) => order.order_id !== orderId)
      );
      console.log(`Order ${orderId} completed and deleted.`);
    } catch (error) {
      console.error(`Error deleting order ${orderId}:`, error);
    }
  };

  if (loading) return <div>Loading...</div>;

  if (orders.length === 0) {
    return (
      <div className="flex justify-center">
        <div className="text-9xl font-bold text-gray-500">No Current Orders</div>
      </div>
    );
  }

  return (
    <div className="flex justify-center">
      <div className="grid grid-cols-5 gap-4">
        {orders.map((order) => (
          <KioskOrder
            key={order.order_id}
            timeSinceOrder={order.order_created}
            orderId={order.order_id}
            items={order.items}
            onComplete={handleComplete}
          />
        ))}
      </div>
    </div>
  );
}

export default KioskOrderList;
