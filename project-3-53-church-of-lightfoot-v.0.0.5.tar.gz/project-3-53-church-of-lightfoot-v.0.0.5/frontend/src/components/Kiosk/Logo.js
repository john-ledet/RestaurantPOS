import React from 'react';

export const Logo = ({width, height}) => {
    return (
        <img src = "../ImageFolder/Panda_logo.png" 
        alt = "Panda Express Logo" 
        className = {`${width} ${height} object-contain`}
        />
    );
}
