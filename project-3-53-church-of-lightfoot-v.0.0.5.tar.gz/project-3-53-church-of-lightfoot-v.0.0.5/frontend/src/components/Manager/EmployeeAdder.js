// Employee component: has ID, first name, last name, position, active status, and PIN

import React from 'react';

export const EmployeeAdder = ({onClick}) => {
    // squared display that highlights the border when selected
    return (
        <div className="rounded-lg p-4 mb-4">
                <button className="w-[100%] h-[100%] px-3 py-1 bg-red-500 text-white rounded-md" onClick={() => onClick(true)}>Add</button>
        </div>
    );
}

export const EmployeeAdderPopUp = ({onClose, onAdd}) => {
    return (
        <div className="fixed top-[50%] left-[50%] w-[40%] translate-x-[-50%] translate-y-[-50%] p-[20px] bg-white rounded-md border border-gray-300">
            <h3 className="text-lg font-medium">Add New Employee</h3>
            <div>
                <div className="inline-flex mt-4">
                    <p className="w-[100px]">First Name:</p>
                    <input className="border ml-4" type="text" id="firstName" />
                </div>
                <div className="inline-flex mt-4">
                    <p className="w-[100px]">Last Name:</p>
                    <input className="border ml-4" type="text" id="lastName" />
                </div>
                <div className="inline-flex mt-4">
                    <p className="w-[100px]">Position:</p>
                    <input className="border ml-4" type="text" id="position" />
                </div>
                <div className="inline-flex mt-4">
                    <p className="w-[100px]">PIN:</p>
                    <input className="border ml-4" type="text" id="pin" />
                </div>
            </div>
            <div className="flex justify-between mt-4">
                <button className="px-3 py-1 bg-red-500 text-white rounded-md" onClick={() => onClose(false)}>Close</button>
                <button className="px-3 py-1 bg-red-500 text-white rounded-md" onClick={() => onAdd(
                    document.getElementById("firstName").value,
                    document.getElementById("lastName").value,
                    document.getElementById("position").value,
                    document.getElementById("pin").value,
                    )}>Add</button>
            </div>
        </div>
    );
}