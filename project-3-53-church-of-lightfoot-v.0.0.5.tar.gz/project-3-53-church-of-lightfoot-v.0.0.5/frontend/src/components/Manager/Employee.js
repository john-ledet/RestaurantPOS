// Employee component: has ID, first name, last name, position, active status, and PIN

import { React, useEffect, useState } from "react";
import { executeGet, executePost, executeDelete } from "../../util/Requests";

// ==================================
// Backend interactivity functions
// ==================================

export const fetchData = async (setEmployees) => {
  try {
    const data = await executeGet(`employees`, {}, "GET");
    setEmployees(data); // Set fetched data directly
  } catch (error) {
    console.error("Error fetching employees:", error);
  }
};

export const addEmployee = async (
  first_name,
  last_name,
  position,
  pin_id,
  setEmployeeAdder,
  setEmployees
) => {
  try {
    const response = await executePost("employees/add", {
      first_name,
      last_name,
      position,
      pin_id,
    });
    if (response === 200) {
      setEmployeeAdder(false);
      fetchData(setEmployees);
    }
  } catch (error) {
    console.error("Error adding employee:", error);
  }
};

export const deleteEmployee = async (
  employee,
  setEmployeePopUp,
  setEmployees
) => {
  const id = employee.employee_id;
  try {
    const response = await executeDelete(`employees/${id}`, { id });
    if (response === 200) {
      setEmployeePopUp(false);
      fetchData(setEmployees);
    }
  } catch (error) {
    console.error("Error deleting employee:", error);
  }
};

// ==================================
// HTML-related functions
// ==================================

const popup = "fixed top-[50%] left-[50%] w-[40vw] translate-x-[-50%] translate-y-[-50%] p-[20px] bg-white rounded-md border border-gray-300";
const buttonStyle = " bg-red-500 text-white font-semibold rounded-md hover:bg-red-600 active:bg-red-700";

// This is the "card" used for each employee
export const EmployeeCard = ({ onClick, employee }) => {
  return (
    <div className="border border-gray-300 rounded-lg p-4 mb-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">
            {employee.first_name} {employee.last_name}
          </h3>
          <p className="text-sm text-gray-700">ID: {employee.employee_id}</p>
        </div>
        <div className="flex justify-between">
          <button
            className={"px-8 py-6" + buttonStyle}
            onClick={() => onClick(employee)}
          >
            Detailed Information
          </button>
        </div>
      </div>
    </div>
  );
};

// Popup window that displays the currently selected employee's information
export const EmployeePopup = ({ employee, onClose, onDelete }) => {
  return (
    <div className={popup}>
      <h3 className="text-lg font-medium">
        {employee.first_name} {employee.last_name}
      </h3>
      <p>
        Employee ID: <b>{employee.employee_id}</b>
      </p>
      <p>
        Position: <b>{employee.position}</b>
      </p>
      <p>
        Status: <b>{employee.is_active ? "Active" : "Not Active"}</b>
      </p>
      <p>
        PIN: <b>{employee.pin_id}</b>
      </p>
      <div className="flex justify-between mt-4">
        <button
          className={"px-6 py-4 " + buttonStyle}
          onClick={onDelete}
        >
          Delete Employee
        </button>
        <button
          className={"px-6 py-4 " + buttonStyle}
          onClick={onClose}
        >
          Close
        </button>
      </div>
    </div>
  );
};

// This is just a fancy button that will be placed after all the employee cards
export const EmployeeAdder = ({ onClick }) => {
  return (
    <div className="rounded-lg p-4 mb-4">
      <button
        className={"w-[100%] h-[5em] bg-red-500 text-white rounded-md " + buttonStyle}
        onClick={() => onClick(true)}
      >
        Add Employee
      </button>
    </div>
  );
};

// Popup window that gives options to add an employee
export const EmployeeAdderPopUp = ({ onClose, onAdd }) => {
  return (
    <div className={popup}>
      <h3 className="text-lg font-medium">Add New Employee</h3>
      <div>
        <div className="inline-flex w-[100%] mt-4">
          <p className="w-[100px]">First Name:</p>
          <input className="w-[60%] border ml-4" type="text" id="firstName" />
        </div>
        <div className="inline-flex w-[100%] mt-4">
          <p className="w-[100px]">Last Name:</p>
          <input className="w-[60%] border ml-4" type="text" id="lastName" />
        </div>
        <div className="inline-flex w-[100%] mt-4">
          <p className="w-[100px]">Position:</p>
          <input className="w-[60%] border ml-4" type="text" id="position" />
        </div>
        <div className="inline-flex w-[100%] mt-4">
          <p className="w-[100px]">PIN:</p>
          <input className="w-[60%] border ml-4" type="text" id="pin" />
        </div>
      </div>
      <div className="flex justify-between mt-4">
        <button
          className="px-6 py-4 bg-red-500 text-white rounded-md"
          onClick={() => onClose(false)}
        >
          Close
        </button>
        <button
          className="px-6 py-4 bg-red-500 text-white rounded-md"
          onClick={() =>
            onAdd(
              document.getElementById("firstName").value,
              document.getElementById("lastName").value,
              document.getElementById("position").value,
              document.getElementById("pin").value
            )
          }
        >
          Add
        </button>
      </div>
    </div>
  );
};

const Employee = () => {
  const [employees, setEmployees] = useState([]);
  const [currEmployee, setCurrEmployee] = useState(null);
  const [employeePopUp, setEmployeePopUp] = useState(false);
  const [employeeAdder, setEmployeeAdder] = useState(false);

  const cleanup = () => {
    setEmployees([]);
  };

  // Fetch data on initial render
  useEffect(() => {
    fetchData(setEmployees);

    return () => cleanup; // Call cleanup
  }, []);

  // Employee info popup window functions.
  const openPopup = (employee) => {
    setCurrEmployee(employee);
    setEmployeePopUp(true);
  };
  const closePopup = () => {
    setEmployeePopUp(false);
    setCurrEmployee(null);
  };

  // Employee adder function
  const setAddEmployee = async (first_name, last_name, position, pin_id) => {
    addEmployee(
      first_name,
      last_name,
      position,
      pin_id,
      setEmployeeAdder,
      setEmployees
    );
  };

  // Employee deleter function
  const setDeleteEmployee = async () => {
    deleteEmployee(currEmployee, setEmployeePopUp, setEmployees);
  };

  return (
    <div className="p-2 relative h-[85vh] overflow-y-auto rounded-md border border-gray-300">
      <EmployeeAdder onClick={setEmployeeAdder} />

      {/* Lists all employees in the database with their names and IDs. */}
      {employees.map((employee) => (
        <EmployeeCard
          key={employee.employee_id}
          employee={employee}
          onClick={openPopup}
        />
      ))}

      {/* Employee Pop-up window that is dependent on the employee with the clicked Info. */}
      {employeePopUp && (
        <EmployeePopup
          employee={currEmployee}
          onClose={closePopup}
          onDelete={setDeleteEmployee}
        />
      )}
      {/* Employee Adder Pop-up window. */}
      {employeeAdder && (
        <EmployeeAdderPopUp onClose={setEmployeeAdder} onAdd={setAddEmployee} />
      )}
    </div>
  );
};

export default Employee;