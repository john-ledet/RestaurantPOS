import React, { useState, useEffect } from "react";
import { Bar } from "react-chartjs-2";
import DatePicker from "react-datepicker";
import { executeGet } from "../../util/Requests";
import "react-datepicker/dist/react-datepicker.css";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  BarElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend
);

const dateFormatter = (initialDate, isEndDate = false) => {
  const date = initialDate;

  if (isEndDate) {
    date.setHours(23);
    date.setMinutes(59);
    date.setSeconds(59);
    date.setMilliseconds(0);
  } else {
    date.setHours(6);
    date.setMinutes(0);
    date.setSeconds(0);
    date.setMilliseconds(0);
  }

  return date;
};

const UsageChart = () => {
  const [inventoryItems, setInventoryItems] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [chartData, setChartData] = useState(null);
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [selectedUnit, setUnit] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await executeGet(`inventory`, {}, "GET");
        setInventoryItems(data);
      } catch (error) {
        console.error("Failed to fetch inventory data.", error);
      }
    };
    fetchData();
  }, []);

  const fetchItemUsageData = async (name, startDate, endDate) => {
    if (!startDate || !endDate || startDate > endDate) {
      alert("Second date must be after or the same as the first date");
      return;
    }

    try {
      const data = await executeGet(
        `itemusage?name=${name}&startDate=${startDate.toISOString()}&endDate=${endDate.toISOString()}`,
        {
          name,
          startDate: startDate.toISOString().split("T")[0],
          endDate: endDate.toISOString().split("T")[0],
        }
      );

      const chartLabels = data.map((item) => item.usage_date.split("T")[0]);
      const chartValues = data.map((item) => item.total_usage);

      console.log("Labels: ", chartLabels);
      console.log("Values: ", chartData);

      setChartData({
        labels: chartLabels,
        datasets: [
          {
            label: `${formatName(name)}Usage (${selectedItem.unit})`,
            data: chartValues,
            backgroundColor: "rgba(239, 68, 68, 0.6)",
          },
        ],
      });
    } catch (error) {
      console.error("Error fetching usage data", error);
    }
  };

  const handleItemSelect = (event) => {
    const selectedName = event.target.value;
    const selected = inventoryItems.find((item) => item.name === selectedName);
    setSelectedItem(selected);
    setUnit(selected?.unit);
    console.log("Selected Item:", selected);
  };

  const handleGenerateChart = () => {
    if (selectedItem && startDate && endDate) {
      fetchItemUsageData(selectedItem.name, startDate, endDate);
    } else {
      alert("Select an item and start/end dates.");
    }
  };

  const formatName = (name) => {
    var str = name.replaceAll("_", " ");
    var out = "";
    var list = str.split(" ");
    for (var word of list) {
      out += String(word).charAt(0).toUpperCase() + String(word).slice(1) + " ";
    }
    return out;
  };

  return (
    <div>
      <form class="max-w-sm mx-auto">
        <label for="item" class="block mb-2 text-sm font-medium text-gray-700">
          Select an inventory item
        </label>
        <select
          value={selectedItem?.name || ""}
          onChange={handleItemSelect}
          class="bg-gray-50 border border-gray-300 text-gray-700 text-sm rounded-md focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
        >
          <option className="bg-gray-50 text-xs text-gray-700" value="" disabled>~Inventory item~</option>
          {inventoryItems.map((item) => (
            <option
              className="bg-gray-50 text-xs text-gray-700"
              value={item.name}
              key={item.name}
            >
              {formatName(item.name)} ({item.unit})
            </option>
          ))}
        </select>
      </form>
      <div className="flex">
        <div className="">
          {selectedItem && (
            <div>
              <h3 className="text-xl font-bold w-[50rem]">
                Inventory usage for{" "}
                <span className="text-red-500">
                  {formatName(selectedItem.name)}
                </span>{" "}
                ({selectedItem.unit})
              </h3>
              <div className="flex items-center gap-[2rem]">
                <div>
                  <h3 className="text-lg font-medium">Start Date</h3>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(dateFormatter(date))}
                    isClearable
                    inline
                  />
                </div>
                <div>
                  <h3 className="text-lg font-medium">End Date</h3>
                  <DatePicker
                    selected={endDate}
                    onChange={(date) => setEndDate(dateFormatter(date, true))}
                    minDate={startDate}
                    isClearable
                    inline
                  />
                </div>
              </div>
              <button
                className="px-3 py-1 bg-red-500 text-white rounded-md"
                onClick={handleGenerateChart}
              >
                Generate Chart
              </button>
            </div>
          )}
        </div>
        <div>
          {chartData && (
            <div className="p-1 w-[40rem] h-[18rem] mt-[1rem] ml-[-10vw] border rounded-md border border-gray-300">
              <Bar
                data={chartData}
                options={{
                  responsive: true,
                  plugins: {
                    legend: {
                      display: true,
                      labels: {
                        font: {
                          size: 16, // Adjust the font size if needed
                          weight: "bold",
                          family: "Arial, sans-serif", // Use a clear and common font
                        },
                      },
                    },
                  },
                  scales: {
                    x: {
                      title: {
                        display: true, // Show the x-axis label
                        text: "Date", // Label text
                        font: {
                          size: 12, // Font size for the x-axis label
                          weight: "bold", // Font weight for better visibility
                          family: "Arial, sans-serif", // Font family
                        },
                      },
                      ticks: {
                        font: {
                          size: 12,
                        },
                      },
                    },
                    y: {
                      title: {
                        display: true, // Show the y-axis label
                        text: `${selectedUnit}`, // Label text
                        font: {
                          size: 12, // Font size for the y-axis label
                          weight: "bold", // Font weight for better visibility
                          family: "Arial, sans-serif", // Font family
                        },
                      },
                      ticks: {
                        font: {
                          size: 12,
                        },
                      },
                    },
                  },
                }}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UsageChart;
