import React, {useState} from 'react';

export const SeasonalAdder = ({onClick}) => {
    // squared display that highlights the border when selected
    return (
        <div className="rounded-lg p-4 mb-4">
                <button className="w-[100%] h-[100%] px-3 py-1 bg-red-500 text-white rounded-md" onClick={() => onClick(true)}>Add</button>
        </div>
    );
}

export const SeasonalAdderPopUp = ({onClose, onAdd}) => {
    const [name, setName] = useState("");
    const [price, setPrice] = useState("");

    const handleAdd = () => {
        if (!name.trim() || !price.trim() || isNaN(price)) {
            alert("Please enter a valid name and numeric price.");
            return;
        }
        onAdd(name, parseFloat(price));
        setName(""); 
        setPrice(""); 
    };

    return (
        <div className="fixed top-[50%] left-[50%] w-[40%] translate-x-[-50%] translate-y-[-50%] p-[20px] bg-white rounded-md border border-gray-300">
            <h3 className="text-lg font-medium">Add New Seasonal Item</h3>
            <div>
                <div className="inline-flex mt-4">
                    <p className="w-[100px]">name:</p>
                    <input className="border ml-4" type="text" id="firstName" value = {name} onChange = {(e) => setName(e.target.value)}/>
                </div>
                <div className="inline-flex mt-4">
                    <p className="w-[100px]">price:</p>
                    <input className="border ml-4" type="text" id="price" value = {price} onChange = {(e) => setPrice(e.target.value)} />
                </div>
            </div>
            <div className="flex justify-between mt-4">
                <button className="px-3 py-1 bg-red-500 text-white rounded-md" onClick={() => onClose(false)}>Close</button>
                <button className="px-3 py-1 bg-red-500 text-white rounded-md" onClick={handleAdd}>Add</button>
            </div>
        </div>
    );
}