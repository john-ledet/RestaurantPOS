import React, { useState, useEffect } from "react";
import { SeasonalTable } from "./SeasonalTable";
import { SeasonalAdder, SeasonalAdderPopUp } from "./SeasonalAdder";
import { executeGet, executePost, executeDelete } from "../../util/Requests";

const Services = () => {
    const [seasonalItems, setSeasonalItems] = useState([]);
    const [isAdding, setIsAdding] = useState(false);

    const fetchSeasonalItems = async () => {
        try {
            const data = await executeGet('seasonal', {}, 'GET');
            setSeasonalItems(data);
        } catch (error) {
            console.error("Error fetching seasonal items:", error);
        }
    }

    const addSeasonalItem = async (name, price) => {
        try {
          const response = await executePost("seasonal/add", { name, price });
          if (response.status === 200) {
            setIsAdding(false);
            fetchSeasonalItems();
            alert("You have successfully added a new seasonal item.");
          }
          else {
            alert("You have successfully added a new seasonal item.");
          }
        } catch (error) {
          console.error("Error adding seasonal item:", error);
          alert("Error adding item. Please check the console for more details.");
        }
    };
    
    const removeSeasonalItem = async (id) => {
        try {
          const response = await executeDelete(`seasonal/${id}`, {});
          if (response.status === 200) {
            fetchSeasonalItems();
            alert("You have successfully deleted a seasonal item.");
          }
          else {
            alert("You have successfully deleted a seasonal item.");
          }
        } catch (error) {
          console.error("Error deleting seasonal item:", error);
        }
      };
    
      useEffect(() => {
        fetchSeasonalItems();
      }, []);
    
    return (
        <div>
            {/*Seasonal Table */}
            <SeasonalTable items = {seasonalItems} onRemove = {removeSeasonalItem} />

            {/*Add Seasonal Button */}
            <SeasonalAdder onClick = {() => setIsAdding(true)} />

            {/*PopUp*/}
            {isAdding && (
                <SeasonalAdderPopUp
                onClose={() => setIsAdding(false)}
                onAdd={addSeasonalItem}
                />
            )}           
        </div>
    );
};

export default Services;


